# Lakemont Physio - testimonials

All three people gave written permission, approved the wording, and chose how their name appears.
(Fictional sample data for the book's worked example.)

## 1
Name as it appears: Maria T., office manager
Text: "I came in after three months of lower back pain at my desk. After the first session I had a written plan and five exercises, and by week four I was sitting through full workdays again."

## 2
Name as it appears: Andrei P., amateur runner
Text: "I sprained my ankle six weeks before a half marathon. They built the rehab around my training plan, and I ran the race."

## 3
Name as it appears: Elena R.
Text: "After my knee surgery, every session was a full 45 minutes and nobody rushed me. The home program they wrote kept me on track between visits."
