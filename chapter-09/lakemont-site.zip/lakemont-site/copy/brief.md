# Lakemont Physio - site brief
Name on site: Lakemont Physio
One sentence: Physiotherapy for back pain, sports injuries, and post-surgery recovery, in central Lakemont.
Audience: office workers and recreational athletes, 25-60
Primary action: Book an assessment (link: cal.com/lakemont)
Phone: +40 356 000 000 (also on WhatsApp)
Services: back and neck pain, sports injury rehab, post-surgery recovery, posture assessment, dry needling
Why us: same-week appointments; 45-minute sessions, never rushed; a written home program after every visit
True credentials: both therapists licensed, 9 and 12 years
Hours: Mon-Fri 8:00-20:00, Sat 9:00-13:00
Testimonials: three attached in this folder, with consent
Tone: calm, specific, unhurried, no ad-speak
