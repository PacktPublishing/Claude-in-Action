# media/

Put your own photos here: the team, the treatment room, the work.
Suggested names: team-1.jpg, team-2.jpg, treatment-room.jpg, session.jpg.

This sample pack ships without photos. If the folder has no photos, both paths in
Chapter 9 place matching stock images from Unsplash and mark every one of them with
a SWAP comment, so you can replace them with your own photos later.
