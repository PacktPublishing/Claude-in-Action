# one-shot-website version history

The current version is in `SKILL.md`, in the frontmatter (`metadata.version`) and in the title. When you change the skill, update both places and add an entry here.

Numbering (MAJOR.MINOR.PATCH):
- **MAJOR:** the user's flow changes (steps added or removed, a different way to start, a different stack).
- **MINOR:** a new capability that keeps the flow (a new site type, a new branding option).
- **PATCH:** wording fixes, clarified rules, repaired scripts.

## 1.0.0 (2026-10-25)

- First release for *Learn Claude by Building 9 Business Automation Projects*, Chapter 9.
- 8 guided steps, or answers read from a prepared brief; `demo` and `publish` arguments.
- Builds directly in the current, empty folder; the project, repository and Vercel names come from the folder name.
- 5 brand directions with a contrast check and a browser preview; colors and fonts from a site the user likes, or from their own logo and colors.
- React, Vite, Tailwind CSS, GSAP and Lucide at the latest versions, checked with `npm view` on every run.
- Writing rules for the site copy packaged inside the skill (`references/writing-rules.md`); no other skill is needed.
- Automatic mobile check with desktop and phone screenshots (`scripts/check-mobile.mjs`).
- Publishing through the GitHub and Vercel connectors (command-line fallback), a README with four domain options, and the update loop.
