// Shared color helpers: parsing, conversions, WCAG contrast.
// Used by check-palette.mjs and extract-colors.mjs. No dependencies.

const NAMED = {
  white: '#ffffff', black: '#000000', red: '#ff0000', green: '#008000', blue: '#0000ff',
  gray: '#808080', grey: '#808080', silver: '#c0c0c0', navy: '#000080', teal: '#008080',
  orange: '#ffa500', yellow: '#ffff00', gold: '#ffd700', maroon: '#800000', olive: '#808000',
  whitesmoke: '#f5f5f5', ivory: '#fffff0', beige: '#f5f5dc',
}

const clamp01 = (x) => Math.min(1, Math.max(0, x))

function parseAlpha(a) {
  if (a === undefined) return 1
  a = a.trim()
  return a.endsWith('%') ? parseFloat(a) / 100 : parseFloat(a)
}

function parseChannel(v, max = 255) {
  v = v.trim()
  return v.endsWith('%') ? (parseFloat(v) / 100) * max : parseFloat(v)
}

function linearToSrgb(c) {
  const v = c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055
  return Math.round(clamp01(v) * 255)
}

function oklabToRgb(L, a, b) {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b
  const s_ = L - 0.0894841775 * a - 1.291485548 * b
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3
  return [
    linearToSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
    linearToSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
    linearToSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s),
  ]
}

function hslToRgb(h, s, l) {
  h = ((h % 360) + 360) % 360
  const c = (1 - Math.abs(2 * l - 1)) * s
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1))
  const m = l - c / 2
  let r = 0, g = 0, b = 0
  if (h < 60) [r, g, b] = [c, x, 0]
  else if (h < 120) [r, g, b] = [x, c, 0]
  else if (h < 180) [r, g, b] = [0, c, x]
  else if (h < 240) [r, g, b] = [0, x, c]
  else if (h < 300) [r, g, b] = [x, 0, c]
  else [r, g, b] = [c, 0, x]
  return [Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255)]
}

// Takes a CSS color string; returns { rgb: [r,g,b], alpha } or null.
export function parseColor(str) {
  const out = parseRaw(str)
  if (!out || out.rgb.some((v) => !Number.isFinite(v))) return null
  out.rgb = out.rgb.map((v) => Math.min(255, Math.max(0, v)))
  if (!Number.isFinite(out.alpha)) out.alpha = 1
  return out
}

function parseRaw(str) {
  if (!str) return null
  const s = str.trim().toLowerCase()
  if (NAMED[s]) return parseRaw(NAMED[s])
  let m = s.match(/^#([0-9a-f]{3,8})$/)
  if (m) {
    let h = m[1]
    if (h.length === 3 || h.length === 4) h = h.split('').map((c) => c + c).join('')
    if (h.length !== 6 && h.length !== 8) return null
    const rgb = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16))
    const alpha = h.length === 8 ? parseInt(h.slice(6, 8), 16) / 255 : 1
    return { rgb, alpha }
  }
  m = s.match(/^rgba?\((.+)\)$/)
  if (m) {
    const parts = m[1].replace(/\//, ',').split(/[\s,]+/).filter(Boolean)
    if (parts.length < 3) return null
    return { rgb: parts.slice(0, 3).map((p) => Math.round(parseChannel(p))), alpha: parseAlpha(parts[3]) }
  }
  m = s.match(/^hsla?\((.+)\)$/)
  if (m) {
    const parts = m[1].replace(/\//, ',').split(/[\s,]+/).filter(Boolean)
    if (parts.length < 3) return null
    const h = parseFloat(parts[0])
    const sat = parseFloat(parts[1]) / 100
    const lig = parseFloat(parts[2]) / 100
    return { rgb: hslToRgb(h, sat, lig), alpha: parseAlpha(parts[3]) }
  }
  m = s.match(/^oklch\((.+)\)$/)
  if (m) {
    const parts = m[1].replace(/\//, ' / ').split(/\s+/).filter(Boolean)
    const slash = parts.indexOf('/')
    const [Ls, Cs, Hs] = parts
    if (!Hs) return null
    const L = Ls.endsWith('%') ? parseFloat(Ls) / 100 : parseFloat(Ls)
    const C = Cs.endsWith('%') ? (parseFloat(Cs) / 100) * 0.4 : parseFloat(Cs)
    const H = (parseFloat(Hs) * Math.PI) / 180
    if ([L, C].some(Number.isNaN)) return null
    const hh = Number.isNaN(H) ? 0 : H
    return { rgb: oklabToRgb(L, C * Math.cos(hh), C * Math.sin(hh)), alpha: slash > -1 ? parseAlpha(parts[slash + 1]) : 1 }
  }
  return null
}

export function toHex([r, g, b]) {
  return '#' + [r, g, b].map((v) => v.toString(16).padStart(2, '0')).join('').toUpperCase()
}

export function luminance([r, g, b]) {
  const f = (v) => {
    v /= 255
    return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)
  }
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
}

export function contrast(a, b) {
  const la = luminance(a), lb = luminance(b)
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05)
}

// Hue (0-360), saturation and lightness (0-1), HSL model.
export function toHsl([r, g, b]) {
  r /= 255; g /= 255; b /= 255
  const max = Math.max(r, g, b), min = Math.min(r, g, b)
  const l = (max + min) / 2
  if (max === min) return { h: 0, s: 0, l }
  const d = max - min
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
  let h
  if (max === r) h = (g - b) / d + (g < b ? 6 : 0)
  else if (max === g) h = (b - r) / d + 2
  else h = (r - g) / d + 4
  return { h: h * 60, s, l }
}

// Purple = hue between 245 and 330 degrees (violet, lavender, purple, magenta), with visible saturation.
export function isPurple(rgb) {
  const { h, s, l } = toHsl(rgb)
  return h >= 245 && h <= 330 && s > 0.15 && l > 0.08 && l < 0.95
}
