// Checks brand directions: WCAG contrast, no default purple, variety.
// Usage: node check-palette.mjs <file.json>
// The file holds one object or a list of objects
//   (or the preview object, { "directions": [...] }):
//   { "name": "...", "base": "#hex", "accent": "#hex", "ink": "#hex", "panel": "#hex",
//     "muted": "#hex" (optional), "allowPurple": true (optional, for the user's own brand colors) }
// Exits with code 1 if any direction fails.

import { readFileSync } from 'node:fs'
import { parseColor, contrast, isPurple, toHex, luminance, toHsl } from './colors.mjs'

const file = process.argv[2]
if (!file) {
  process.stderr.write('Usage: node check-palette.mjs <file.json>\n')
  process.exit(2)
}

let data = JSON.parse(readFileSync(file, 'utf8'))
// Also accepts the preview format: { directions: [...] }.
if (!Array.isArray(data) && Array.isArray(data.directions)) data = data.directions
if (!Array.isArray(data)) data = [data]

const ROLES = ['base', 'accent', 'ink', 'panel']
const CANDIDATES = { white: [255, 255, 255], black: [0, 0, 0] }
let allOk = true
const report = []

for (const [i, d] of data.entries()) {
  const name = d.name || `Direction ${i + 1}`
  const errors = []
  const warnings = []
  const c = {}
  for (const role of [...ROLES, 'muted']) {
    if (!d[role]) {
      if (role !== 'muted') errors.push(`missing color "${role}"`)
      continue
    }
    const parsed = parseColor(d[role])
    if (!parsed) errors.push(`color "${role}" (${d[role]}) can't be read`)
    else c[role] = parsed.rgb
  }
  if (errors.length === 0) {
    if (!d.allowPurple) {
      for (const role of Object.keys(c)) {
        if (isPurple(c[role])) errors.push(`"${role}" ${toHex(c[role])} is purple (hue ${Math.round(toHsl(c[role]).h)}°); pick another hue, or set "allowPurple": true if these are the user's own brand colors`)
      }
    }
    const inkBase = contrast(c.ink, c.base)
    const inkPanel = contrast(c.ink, c.panel)
    const accentBase = contrast(c.accent, c.base)
    if (inkBase < 4.5) errors.push(`text on background: ${inkBase.toFixed(2)}:1, minimum 4.5:1`)
    else if (inkBase < 7) warnings.push(`text on background: ${inkBase.toFixed(2)}:1 (passes; ideally above 7:1)`)
    if (inkPanel < 4.5) errors.push(`text on cards: ${inkPanel.toFixed(2)}:1, minimum 4.5:1`)
    if (accentBase < 3) warnings.push(`accent on background: ${accentBase.toFixed(2)}:1, below 3:1. Use the accent only as a button or strip background (with the text color below), never as text or a thin line on the background`)
    if (c.muted && contrast(c.muted, c.base) < 4.5) errors.push(`secondary text on background: ${contrast(c.muted, c.base).toFixed(2)}:1, minimum 4.5:1`)

    // Which text color reads on a button in the accent color.
    const options = { ink: c.ink, base: c.base, ...CANDIDATES }
    let best = null
    for (const [label, rgb] of Object.entries(options)) {
      const ratio = contrast(rgb, c.accent)
      if (!best || ratio > best.ratio) best = { label, hex: toHex(rgb), ratio }
    }
    if (best.ratio < 4.5) errors.push(`no text color reads on the accent button (best ${best.ratio.toFixed(2)}:1); change the accent`)
    report.push({
      name,
      ok: errors.length === 0,
      background: luminance(c.base) > 0.4 ? 'light' : 'dark',
      buttonText: `${best.label} ${best.hex} (${best.ratio.toFixed(2)}:1)`,
      buttonTextHex: best.hex,
      textContrast: `${inkBase.toFixed(2)}:1`,
      errors,
      warnings,
    })
  } else {
    report.push({ name, ok: false, errors, warnings })
  }
  if (errors.length) allOk = false
}

// Variety, only when there are several directions.
const general = []
if (data.length >= 3) {
  const light = report.filter((r) => r.background === 'light').length
  const dark = report.filter((r) => r.background === 'dark').length
  if (light === 0) general.push('no direction with a light background; make at least one')
  if (dark === 0) general.push('no direction with a dark background; make at least one')
  const accents = data.map((d) => parseColor(d.accent)?.rgb).filter(Boolean).map(toHsl)
  for (let a = 0; a < accents.length; a++) {
    for (let b = a + 1; b < accents.length; b++) {
      const diff = Math.min(Math.abs(accents[a].h - accents[b].h), 360 - Math.abs(accents[a].h - accents[b].h))
      const bothGrey = accents[a].s < 0.15 && accents[b].s < 0.15
      if (diff < 20 && !bothGrey && Math.abs(accents[a].l - accents[b].l) < 0.15) {
        general.push(`directions ${a + 1} and ${b + 1} have nearly identical accents; make them different`)
      }
    }
  }
  if (general.length) allOk = false
}

process.stdout.write(JSON.stringify({ ok: allOk, directions: report, general }, null, 2) + '\n')
process.exit(allOk ? 0 : 1)
