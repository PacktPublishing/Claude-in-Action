// Takes screenshots (desktop + phone) and checks whether the page is phone-friendly.
// Usage: node check-mobile.mjs <url> [--out <folder>] [--name <prefix>] [--wait <ms>] [--no-screenshots]
//
// Starts the Chrome (or Edge/Chromium) installed on the computer, without a window, and drives it
// through the DevTools protocol. No dependencies; needs Node 22+ (global WebSocket).
// The screenshots show only what's visible on load (no scrolling):
//   <prefix>-desktop.png (1440x900) and <prefix>-phone.png (390x844, a phone screen).
// The mobile report (JSON) checks, at 375px width:
//   horizontal scrolling, elements going off-screen, buttons/links under 24px (problem) or under 44px (warning),
//   text that's too small, the viewport meta tag, content still hidden after scrolling, images that don't load.
// Exits with code 1 if it finds mobile problems.

import { spawn, execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'

const args = process.argv.slice(2)
const opt = (flag, fallback) => {
  const i = args.indexOf(flag)
  return i > -1 ? args[i + 1] : fallback
}
const url = args.find((a, i) => !a.startsWith('--') && !['--out', '--name', '--wait'].includes(args[i - 1]))
if (!url) {
  process.stderr.write('Usage: node check-mobile.mjs <url> [--out <folder>] [--name <prefix>] [--wait <ms>] [--no-screenshots]\n')
  process.exit(2)
}
if (typeof WebSocket === 'undefined') {
  process.stderr.write('This script needs Node 22 or newer (global WebSocket).\n')
  process.exit(2)
}
const outDir = resolve(opt('--out', '.'))
const prefix = opt('--name', 'site')
const waitMs = Number(opt('--wait', '3500'))
const noScreenshots = args.includes('--no-screenshots')

function findChrome() {
  if (process.env.CHROME_PATH && existsSync(process.env.CHROME_PATH)) return process.env.CHROME_PATH
  const pf = process.env.PROGRAMFILES || 'C:\\Program Files'
  const pf86 = process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)'
  const local = process.env.LOCALAPPDATA || ''
  const candidates = [
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
    `${pf}\\Google\\Chrome\\Application\\chrome.exe`,
    `${pf86}\\Google\\Chrome\\Application\\chrome.exe`,
    `${local}\\Google\\Chrome\\Application\\chrome.exe`,
    `${pf86}\\Microsoft\\Edge\\Application\\msedge.exe`,
    `${pf}\\Microsoft\\Edge\\Application\\msedge.exe`,
  ]
  for (const c of candidates) if (c && existsSync(c)) return c
  for (const bin of ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge']) {
    try {
      const found = execFileSync('which', [bin], { encoding: 'utf8' }).trim()
      if (found) return found
    } catch {
      // not on this system
    }
  }
  return null
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const chrome = findChrome()
if (!chrome) {
  process.stderr.write('Chrome, Edge or Chromium not found. Install Google Chrome or set CHROME_PATH.\n')
  process.exit(2)
}

const port = 9300 + Math.floor(Math.random() * 500)
const profile = mkdtempSync(join(tmpdir(), 'check-mobile-'))
const browser = spawn(chrome, [
  '--headless=new',
  '--disable-gpu',
  '--hide-scrollbars',
  '--no-first-run',
  '--no-default-browser-check',
  '--mute-audio',
  `--remote-debugging-port=${port}`,
  `--user-data-dir=${profile}`,
  'about:blank',
], { stdio: 'ignore' })

async function close(code) {
  try { browser.kill() } catch { /* already stopped */ }
  await sleep(300)
  try { rmSync(profile, { recursive: true, force: true }) } catch { /* stays in the system temp folder */ }
  process.exit(code)
}

let ws
let nextId = 1
const pending = new Map()
const listeners = []

function send(method, params = {}) {
  const id = nextId++
  ws.send(JSON.stringify({ id, method, params }))
  return new Promise((resolveFn, rejectFn) => {
    pending.set(id, { resolveFn, rejectFn })
    setTimeout(() => {
      if (pending.has(id)) {
        pending.delete(id)
        rejectFn(new Error(`Timed out on ${method}`))
      }
    }, 60000)
  })
}

function waitForEvent(name, ms = 30000) {
  return new Promise((resolveFn) => {
    const t = setTimeout(() => resolveFn(null), ms)
    listeners.push({ name, f: (p) => { clearTimeout(t); resolveFn(p) } })
  })
}

async function connect() {
  for (let i = 0; i < 60; i++) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json()
      const page = list.find((t) => t.type === 'page')
      if (page) return page.webSocketDebuggerUrl
    } catch {
      // Chrome is still starting
    }
    await sleep(250)
  }
  throw new Error('Chrome did not start in time')
}

const UA_PHONE = 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1'

async function openPage({ width, height, scale, phone }) {
  await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: scale, mobile: phone })
  await send('Emulation.setTouchEmulationEnabled', phone ? { enabled: true, maxTouchPoints: 5 } : { enabled: false })
  await send('Network.setUserAgentOverride', { userAgent: phone ? UA_PHONE : '' })
  const loaded = waitForEvent('Page.loadEventFired')
  await send('Page.navigate', { url })
  await loaded
  await send('Runtime.evaluate', { expression: 'document.fonts.ready.then(() => true)', awaitPromise: true })
  await sleep(waitMs)
  await send('Runtime.evaluate', { expression: "window.scrollTo({ top: 0, behavior: 'instant' })" })
  await sleep(300)
}

async function screenshot(file) {
  const { data } = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  writeFileSync(file, Buffer.from(data, 'base64'))
}

// Runs inside the page. Scrolls the whole page instantly (so scroll animations start),
// then collects the mobile problems.
const CHECK = `(async () => {
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
  const H = () => document.documentElement.scrollHeight
  for (let y = 0; y < H(); y += Math.round(innerHeight * 0.6)) { window.scrollTo({ top: y, behavior: 'instant' }); await sleep(120) }
  window.scrollTo({ top: H(), behavior: 'instant' }); await sleep(1200)
  const width = document.documentElement.clientWidth
  const visible = (el) => { if (el.closest('details:not([open])') && !el.closest('summary')) return false; const s = getComputedStyle(el); const r = el.getBoundingClientRect(); return s.display !== 'none' && s.visibility !== 'hidden' && +s.opacity > 0.05 && r.width > 0 && r.height > 0 }
  const classes = (el) => { const c = (typeof el.className === 'string' ? el.className : '').trim().split(/\s+/).filter(Boolean).slice(0, 2); if (c.length) return '.' + c.join('.'); const p = el.parentElement; const pc = p && typeof p.className === 'string' ? p.className.trim().split(/\s+/).filter(Boolean)[0] : ''; return pc ? ' (in .' + pc + ')' : '' }
  const describe = (el) => (el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + classes(el) + ' "' + (el.innerText || el.getAttribute('aria-label') || '').trim().replace(/\\s+/g, ' ').slice(0, 40) + '"')
  // Finds text and interactive elements that go off-screen. Ignores decoration (aria-hidden),
  // strips that scroll on purpose (an ancestor with overflow auto/scroll) and fixed elements.
  const offScreen = []
  const hasOwnText = (el) => [...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim().length > 1)
  for (const el of document.querySelectorAll('body *')) {
    if (!visible(el) || el.closest('[aria-hidden="true"]')) continue
    if (!hasOwnText(el) && !el.matches('a[href], button, input, select, textarea')) continue
    if (getComputedStyle(el).position === 'fixed') continue
    let p = el.parentElement, scrolls = false
    while (p && p !== document.body) { if (/(auto|scroll)/.test(getComputedStyle(p).overflowX)) { scrolls = true; break } p = p.parentElement }
    if (scrolls) continue
    const r = el.getBoundingClientRect()
    // Text can also overflow its own box (a long word or white-space: nowrap).
    const right = Math.max(r.right, r.left + el.scrollWidth)
    if (right > width + 2 || r.left < -2) offScreen.push(describe(el) + ' (' + Math.round(r.left) + '..' + Math.round(right) + 'px)')
  }
  const smallTargets = []
  const under44 = []
  for (const el of document.querySelectorAll('a[href], button, [role="button"], input, select, textarea')) {
    if (!visible(el) || el.closest('[aria-hidden="true"]')) continue
    const r = el.getBoundingClientRect()
    const inText = el.tagName === 'A' && getComputedStyle(el).display === 'inline' && el.closest('p, li, dd, figcaption')
    if (inText) continue
    const d = describe(el) + ' (' + Math.round(r.width) + 'x' + Math.round(r.height) + 'px)'
    if (r.height < 24 || r.width < 24) smallTargets.push(d)
    else if (r.height < 44) under44.push(d)
  }
  const smallText = []
  const seen = new Set()
  for (const el of document.querySelectorAll('p, li, a, span, dd, dt, td, label, button, figcaption, blockquote')) {
    if (!visible(el) || !el.innerText || !el.innerText.trim() || el.closest('[aria-hidden="true"]')) continue
    const fs = parseFloat(getComputedStyle(el).fontSize)
    const key = el.innerText.trim().slice(0, 30)
    if (fs < 12 && !seen.has(key)) { seen.add(key); smallText.push(describe(el) + ' (' + fs + 'px)') }
  }
  const hidden = [...document.querySelectorAll('section *, main *')].filter((el) => {
    const s = getComputedStyle(el)
    return el.children.length < 30 && el.innerText && el.innerText.trim().length > 20 && +s.opacity < 0.1 && s.display !== 'none' && s.visibility !== 'hidden' && !el.closest('[aria-hidden="true"]')
  }).slice(0, 10).map(describe)
  const brokenImages = [...document.images].filter((i) => i.complete && i.naturalWidth === 0).map((i) => i.currentSrc || i.src).slice(0, 10)
  const meta = document.querySelector('meta[name="viewport"]')
  window.scrollTo({ top: 0, behavior: 'instant' })
  return {
    screenWidth: width,
    horizontalScroll: document.documentElement.scrollWidth > width + 1,
    pageWidth: document.documentElement.scrollWidth,
    metaViewport: meta ? meta.content : null,
    offScreen: offScreen.slice(0, 60),
    smallButtonsOrLinks: smallTargets.slice(0, 60),
    under44pxWarning: under44.slice(0, 60),
    textUnder12px: smallText.slice(0, 60),
    hiddenAfterScroll: hidden,
    brokenImages,
  }
})()`

try {
  ws = new WebSocket(await connect())
  await new Promise((r, e) => { ws.onopen = r; ws.onerror = e })
  ws.onmessage = (m) => {
    const msg = JSON.parse(m.data)
    if (msg.id && pending.has(msg.id)) {
      const { resolveFn, rejectFn } = pending.get(msg.id)
      pending.delete(msg.id)
      msg.error ? rejectFn(new Error(msg.error.message)) : resolveFn(msg.result)
    } else if (msg.method) {
      for (let i = listeners.length - 1; i >= 0; i--) {
        if (listeners[i].name === msg.method) { listeners[i].f(msg.params); listeners.splice(i, 1) }
      }
    }
  }
  await send('Page.enable')
  await send('Network.enable')

  const screenshots = []
  if (!noScreenshots) {
    mkdirSync(outDir, { recursive: true })
    await openPage({ width: 1440, height: 900, scale: 1, phone: false })
    const desktop = join(outDir, `${prefix}-desktop.png`)
    await screenshot(desktop)
    screenshots.push(desktop)
    await openPage({ width: 390, height: 844, scale: 3, phone: true })
    const phoneShot = join(outDir, `${prefix}-phone.png`)
    await screenshot(phoneShot)
    screenshots.push(phoneShot)
  }

  await openPage({ width: 375, height: 812, scale: 2, phone: true })
  const { result } = await send('Runtime.evaluate', { expression: CHECK, awaitPromise: true, returnByValue: true })
  const report = result.value
  const problems = []
  if (report.horizontalScroll) problems.push(`the page scrolls sideways (${report.pageWidth}px on a ${report.screenWidth}px screen)`)
  if (!report.metaViewport || !/width=device-width/.test(report.metaViewport)) problems.push('missing <meta name="viewport" content="width=device-width, initial-scale=1.0">')
  if (report.offScreen.length) problems.push(`${report.offScreen.length} texts or buttons go off-screen (cut off on a phone)`)
  if (report.smallButtonsOrLinks.length) problems.push(`${report.smallButtonsOrLinks.length} buttons or links under 24px (the WCAG 2.2 minimum), hard to tap with a finger`)
  if (report.textUnder12px.length) problems.push(`${report.textUnder12px.length} texts under 12px, hard to read on a phone`)
  if (report.hiddenAfterScroll.length) problems.push(`${report.hiddenAfterScroll.length} blocks of text stay invisible after scrolling (an animation that never starts?)`)
  if (report.brokenImages.length) problems.push(`${report.brokenImages.length} images don't load`)

  process.stdout.write(JSON.stringify({ url, ok: problems.length === 0, problems, screenshots, details: report }, null, 2) + '\n')
  await close(problems.length ? 1 : 0)
} catch (err) {
  process.stderr.write(`Error: ${err.message}\n`)
  await close(2)
}
