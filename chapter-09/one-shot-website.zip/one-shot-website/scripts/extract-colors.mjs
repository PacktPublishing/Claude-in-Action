// Extracts the colors and fonts of a site the user likes, as a starting point for branding.
// Usage: node extract-colors.mjs <url> [--out file.json]
// Downloads the page, its linked CSS files (up to 12) and inline styles,
// counts the colors, proposes roles (base, ink, accent, panel) and lists the fonts.
// No dependencies; needs Node 18+ (fetch).

import { writeFileSync } from 'node:fs'
import { parseColor, toHex, luminance, contrast, toHsl, isPurple } from './colors.mjs'

const args = process.argv.slice(2)
const outIdx = args.indexOf('--out')
const outFile = outIdx > -1 ? args[outIdx + 1] : null
let target = args.find((a, i) => !a.startsWith('--') && (outIdx === -1 || i !== outIdx + 1))
if (!target) {
  process.stderr.write('Usage: node extract-colors.mjs <url> [--out file.json]\n')
  process.exit(2)
}
if (!/^https?:\/\//i.test(target)) target = 'https://' + target

const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36'

async function get(url) {
  const res = await fetch(url, { headers: { 'user-agent': UA, accept: '*/*' }, redirect: 'follow', signal: AbortSignal.timeout(15000) })
  if (!res.ok) throw new Error(`${res.status} at ${url}`)
  return { text: await res.text(), url: res.url }
}

const COLOR_RE = /#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)|hsla?\([^)]*\)|oklch\([^)]*\)/g

function collect(css, weight, bag) {
  for (const m of css.matchAll(COLOR_RE)) {
    const p = parseColor(m[0])
    if (!p || p.alpha < 0.5) continue
    const hex = toHex(p.rgb)
    bag.set(hex, (bag.get(hex) || 0) + weight)
  }
}

function backgroundOf(css, selector) {
  const re = new RegExp(`(?:^|[}\\s,])${selector}\\s*[,{][^}]*?background(?:-color)?\\s*:\\s*([^;}]+)`, 'i')
  const m = css.match(re)
  if (!m) return null
  const c = m[1].match(COLOR_RE)
  return c ? parseColor(c[0]) : null
}

function resolveVar(css, value) {
  const v = value.match(/var\((--[\w-]+)/)
  if (!v) return value
  const def = css.match(new RegExp(`${v[1]}\\s*:\\s*([^;}]+)`))
  return def ? def[1] : value
}

try {
  const page = await get(target)
  const html = page.text
  const base = page.url
  const colors = new Map()
  const cssParts = []

  const links = [...html.matchAll(/<link[^>]+>/gi)]
    .map((m) => m[0])
    .filter((tag) => /rel=["']?[^"'>]*stylesheet/i.test(tag))
    .map((tag) => tag.match(/href=["']([^"']+)["']/i)?.[1])
    .filter(Boolean)
  const fontLinks = links.filter((h) => /fonts\.googleapis\.com/.test(h))
  const cssLinks = links.filter((h) => !/fonts\.googleapis\.com/.test(h)).slice(0, 12)

  for (const href of cssLinks) {
    try {
      const css = await get(new URL(href, base).href)
      cssParts.push(css.text)
    } catch {
      // A CSS file that fails to download doesn't stop the analysis.
    }
  }
  for (const m of html.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi)) cssParts.push(m[1])
  const inline = [...html.matchAll(/style=["']([^"']+)["']/gi)].map((m) => m[1]).join(';')

  const allCss = cssParts.join('\n')
  // Variables in :root weigh more; they're usually the brand palette.
  const rootBlocks = [...allCss.matchAll(/:root[^{]*\{([^}]*)\}/g)].map((m) => m[1]).join('\n')
  collect(allCss, 1, colors)
  collect(rootBlocks, 5, colors)
  collect(inline, 2, colors)

  const themeColor = html.match(/<meta[^>]+name=["']theme-color["'][^>]+content=["']([^"']+)["']/i)?.[1]
  if (themeColor && parseColor(themeColor)) {
    const hex = toHex(parseColor(themeColor).rgb)
    colors.set(hex, (colors.get(hex) || 0) + 20)
  }

  const ranked = [...colors.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([hex, count]) => {
      const rgb = parseColor(hex).rgb
      const hsl = toHsl(rgb)
      return { hex, count, rgb, lum: luminance(rgb), s: hsl.s, h: Math.round(hsl.h) }
    })

  // Background: the body/html background, otherwise the most frequent very light or very dark color.
  let bodyBg = backgroundOf(allCss, 'body') || backgroundOf(allCss, 'html')
  if (!bodyBg) {
    const bodyVar = allCss.match(/body\s*\{[^}]*background(?:-color)?\s*:\s*([^;}]+)/i)
    if (bodyVar) bodyBg = parseColor(resolveVar(allCss, bodyVar[1]).trim())
  }
  const baseC = bodyBg ? { hex: toHex(bodyBg.rgb), rgb: bodyBg.rgb, lum: luminance(bodyBg.rgb) } : ranked.find((c) => c.lum > 0.85 || c.lum < 0.02) || { hex: '#FFFFFF', rgb: [255, 255, 255], lum: 1 }
  const isDark = baseC.lum < 0.4

  const ink = ranked
    .filter((c) => c.s < 0.35 && contrast(c.rgb, baseC.rgb) >= 7)
    .sort((a, b) => b.count - a.count)[0] || { hex: isDark ? '#F2F2F2' : '#141414' }

  const accent = ranked
    .filter((c) => c.s > 0.35 && c.lum > 0.03 && c.lum < 0.9 && contrast(c.rgb, baseC.rgb) >= 2)
    .sort((a, b) => b.count - a.count)[0]

  const panel = ranked
    .filter((c) => c.hex !== baseC.hex && c.s < 0.3 && Math.abs(c.lum - baseC.lum) < 0.12 && Math.abs(c.lum - baseC.lum) > 0.003)
    .sort((a, b) => b.count - a.count)[0]

  const fonts = new Map()
  for (const m of allCss.matchAll(/font-family\s*:\s*([^;}]+)/gi)) {
    const first = resolveVar(allCss, m[1]).split(',')[0].trim().replace(/["']/g, '')
    if (first && !/[<>{}]/.test(first) && !/Fallback$/i.test(first) && !/^(inherit|initial|unset|var\(|-apple-system|system-ui|ui-|sans-serif|serif|monospace)/i.test(first)) {
      fonts.set(first, (fonts.get(first) || 0) + 1)
    }
  }
  for (const href of fontLinks) {
    for (const fam of href.matchAll(/family=([^&:]+)/g)) {
      const name = decodeURIComponent(fam[1]).replace(/\+/g, ' ').split(':')[0]
      fonts.set(name, (fonts.get(name) || 0) + 10)
    }
  }

  const warnings = []
  if (ranked.length < 4) warnings.push('found very few colors; the site probably loads its styles from JavaScript. Ask the user for a screenshot or for the colors directly.')
  if (!accent) warnings.push('no clear accent color found; propose one that fits the rest.')
  if (accent && isPurple(accent.rgb)) warnings.push(`the accent found (${accent.hex}) is purple; generated directions avoid purple, so propose the closest allowed hue (blue or coral) and tell the user. If this is the user's own site, keep it and set "allowPurple": true.`)

  const result = {
    source: base,
    proposal: {
      base: baseC.hex,
      ink: ink.hex,
      accent: accent?.hex || null,
      panel: panel?.hex || null,
      background: isDark ? 'dark' : 'light',
    },
    fonts: [...fonts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([f]) => f),
    frequentColors: ranked.slice(0, 15).map(({ hex, count }) => ({ hex, count })),
    warnings,
  }
  const json = JSON.stringify(result, null, 2)
  if (outFile) writeFileSync(outFile, json)
  process.stdout.write(json + '\n')
} catch (err) {
  process.stderr.write(`Couldn't read the site: ${err.message}\n`)
  process.exit(1)
}
