# Site types

Each type has:
- **Keywords:** for matching the demo argument and the free text from "Write my own".
- **Voice:** who speaks on the site.
- **Actions (Step 2):** the options for the main button.
- **Questions (Step 3):** specific to the type, asked after the common ones.
- **Sections (Step 5):** the recommended set, top to bottom.
- **Mood (Step 4):** hints for the 5 brand directions, not rules.
- **Images:** Unsplash search terms.
- **Several pages when:** the signal that one page is no longer enough.

Whatever the type, the sections are a proposal. Adapt them to what the user said and drop anything without content. When the answers come from a brief, use the same fields.

---

## Common questions (Step 3, every type)

Ask these first, then the type's specific questions, in one numbered list.

1. **What name appears on the site?** (your name, the business, the project; for example "Ana Ruiz", "Northside Carpentry", "Small Steps Foundation")
2. **Contact details for [the action chosen at Step 2]:** phone, WhatsApp, email, booking or donation link, as needed. Ask only for what the chosen action needs, plus a secondary one if they want it.
3. **What language is the site in?** 1) English 2) Write my own (another language, or two languages; see the note below)
4. **Does the site speak as "I" or as "we"?** 1) I (I work alone) 2) We (a team or a business) 3) Write my own
5. **Do you have your own photos?** (if yes, tell me where they are on your computer or add them to the chat; if not, I'll place matching images that are easy to replace later)
6. **Do you have a logo?** (if yes, where the file is; if not, I'll set the name nicely in the chosen font)
7. **Links to social profiles or other pages?** (Instagram, Facebook, LinkedIn, TikTok, YouTube, GitHub, Behance; paste the addresses)

**Language note:** one language is the default. Two languages on one site (an EN/ES switch, say) means all the copy twice and more pages; accept it, but tell the user the copy has to be checked in both languages. The writing rules in `writing-rules.md` are written for English; for another language, apply the same principles (no filler, no unsupported claims, short concrete headings).

---

## 1. Portfolio

- **Keywords:** portfolio, designer, photographer, developer, programmer, illustrator, architect, artist, video, work
- **Voice:** first person singular ("I worked", "I make"), or plural for a studio.
- **Actions:** 1) Email me 2) Book a call (Calendly / Cal.com link) 3) See the work (scroll to the gallery, with a secondary contact) 4) Download my résumé (PDF) 5) Write my own
- **Questions:**
  1. What do you do, in one sentence? (for example "I design visual identities for cafés and restaurants")
  2. Who do you usually work for? (small businesses, start-ups, agencies)
  3. Which projects do you want to show? For each: name, client, what you did, 1-3 images or a link. (3-8 recommended)
  4. Which services do you offer, if any? (logo, website, packaging, photo shoots)
  5. Clients or companies you've worked with and want to mention?
  6. Testimonials from clients? (name and what they said)
  7. A few lines about you (where you're from, how you got here)
- **Sections:** Top bar · Hero (name, what you do, action) · Work (grid, a click opens the project large) · Services · About · Clients / testimonials · Contact · Footer
- **Mood:** let the work be the star. Neutral backgrounds (warm white, very light grey, deep black), one accent. Fonts with personality for headings, very clean body text. Editorial, gallery, studio.
- **Images:** creative studio desk, design workspace, camera lens, architecture detail (only if the user has no work to show; for a portfolio the user's work is required, otherwise the Work section gets clearly marked slots)
- **Several pages when:** more than 6 projects with their own text and gallery. Then: main page plus one page per project.

## 2. Personal site / online résumé

- **Keywords:** personal, cv, resume, résumé, about me, bio, profile, business card
- **Voice:** first person singular.
- **Actions:** 1) Email me 2) Connect on LinkedIn 3) Download my résumé (PDF) 4) Book a call 5) Write my own
- **Questions:**
  1. What do you do now, and what are you looking for? (for example "I'm an accountant looking for a role at a larger firm")
  2. Work experience: where, what role, when, one concrete result per place.
  3. Education and certifications.
  4. Skills (languages, tools).
  5. Projects, articles, talks or awards to show.
  6. A few lines about you beyond work.
  7. Do you have a résumé PDF for download?
- **Sections:** Top bar · Hero (name, role, one sentence, photo) · About · Experience (timeline) · Skills · Projects / achievements · Education · Contact · Footer
- **Mood:** clean, confident, personal. Lots of white space, good typography. An accent that says something about the person (warm for people jobs, cool and precise for technical ones).
- **Images:** the user's photo is essential; quiet abstract backgrounds (paper texture, soft gradient light, minimal desk)
- **Several pages when:** many articles or materials (a teacher with resources). Then: main page plus an articles or resources page.

## 3. Hobby / passion

- **Keywords:** hobby, passion, blog, travel, collection, club, fishing, gardening, cooking, games, sport, fan club, hiking, photography
- **Voice:** first person singular or plural (club), relaxed and warm.
- **Actions:** 1) Follow me on [network] 2) Email me 3) Join the group (WhatsApp / Facebook / Discord link) 4) Subscribe to the newsletter (external link, for example Substack) 5) Write my own
- **Questions:**
  1. What's the passion, and since when?
  2. What should people find on the site? (stories, photos, tips, the collection, club meetups)
  3. Stories, articles or journals to include? How many, and about what?
  4. Photos to show? Roughly how many?
  5. Are other people involved? (club, group, friends)
  6. Meetups, outings or events? Where and how often?
- **Sections:** Top bar · Hero (the passion in one sentence, a large image) · My story · Gallery · Articles / stories (if any) · Meetups or events (if any) · Join / follow · Footer
- **Mood:** personal and warm. Colors taken from the passion itself (forest green for hiking, sea blue for sailing, earth tones for pottery). Fonts with character.
- **Images:** straight from the passion (mountain trail, fishing lake morning, pottery hands, vintage stamps)
- **Several pages when:** more than 3-4 articles or stories. Then: main page plus a page per article (or a list page plus articles).

## 4. Trade services

- **Keywords:** trade, tradesperson, electrician, plumber, painter, decorator, carpenter, tiler, roofer, hvac, locksmith, handyman, repairs, renovation, cleaning, gardener, landscaper, movers, mechanic
- **Voice:** ask at Step 3 whether they work alone or with a team. Alone: first person singular everywhere ("I come over", "I install", "I tell you the price"), never "we" or "our team". Team: first person plural.
- **Actions:** 1) Call now (`tel:` link) 2) Message on WhatsApp (`https://wa.me/...` link) 3) Request a quote by email 4) Write my own. **Recommend 1 + 2**: someone looking for a tradesperson wants to call now.
- **Questions:**
  1. What's your trade? (electrician, plumber, painter)
  2. Do you work alone or with a team?
  3. Which city and areas do you cover?
  4. Which services do you offer? Propose a list of 8-14 typical services for their trade, numbered, after they tell you the trade (see the note below). The user picks and adds.
  5. Licenses or certifications that matter in the trade? (if yes, they get prominent placement)
  6. How many years have you been doing this?
  7. Do you guarantee your work? For how long?
  8. Your hours? Do you take emergencies or work weekends?
  9. Photos of your work? A photo of you (it helps trust)?
  10. Customer reviews to include? (name and what they said)
- **Services note:** ask question 4 after you know the trade. If the user answered everything at once, generate the list on the spot and show it so they can choose. Each service gets on the site: a `lucide-react` icon, a title, and one sentence on the problem it solves, in the customer's words ("the power went out", "the sink is leaking", "the paint is peeling").
- **Sections:** Top bar (name + Call button) · Hero ("[Trade] in [city]", Call + WhatsApp, trust badges) · Trust strip (license · years · guarantee · fast response, only what's confirmed) · Services · Why me / why us · How I work (4 steps: you call, I come and look, I give you the price first, I do the job with a guarantee) · Work (if there are photos) · Area · Reviews (only if provided) · FAQ · Final call (Call now) · Footer
- **Special rules:**
  - The phone button appears at least 4 times (hero, after services, area, final call). At least 44px tall on mobile.
  - No long forms. Email is optional and low-key.
  - If they take emergencies: an "Available now" indicator with a pulsing dot, in the footer.
- **Mood:** trustworthy, serious, clear. Colors tied to the trade (electric blue or safety yellow for an electrician, water blue for a plumber, wood tones for a carpenter, workshop grey with orange for heavy work).
- **Images:** the trade at work, with tools (electrician working panel, plumber tools sink, carpenter workshop wood). No images with text, signs or plates in another language.
- **Several pages when:** almost never. One page works better for someone calling from a phone.

## 5. Professional services

- **Keywords:** clinic, practice, doctor, dentist, physio, physiotherapy, physiotherapist, psychologist, therapist, lawyer, notary, accountant, consultant, coach, salon, barber, beauty, massage, vet, fitness, trainer, nutritionist, tutor
- **Voice:** first person singular (solo practice) or plural (a practice with several people). Ask.
- **Actions:** 1) Book an appointment (Calendly / Cal.com / their booking platform) 2) Call 3) Message on WhatsApp 4) Email 5) Contact form through an external service (see the note) 6) Write my own
- **Questions:**
  1. What do you do, and for whom? (for example "Physiotherapy for back pain and sports injuries")
  2. Do you work alone or with colleagues? If colleagues, who are they (name, role, photo)?
  3. Which services do you offer? For each: name, one sentence, length and price if they should appear.
  4. Where is the practice? (address, if you want a map) Or do you work online?
  5. Opening hours.
  6. Education, accreditations, professional memberships (only what should appear).
  7. How does a first appointment go? (helps nervous clients)
  8. Client testimonials you have permission to use?
- **Sections:** Top bar · Hero (what you do + action) · Trust strip (only confirmed credentials) · Services (with price and length if given) · Why us / why me · About / the team · How it works (how the first visit goes; drop it when the action explains itself) · Area (location and hours, with an embedded Google map if there's an address) · Testimonials (if provided) · FAQ · Final call · Footer
- **Mood:** depends a lot on the field. Health and therapy: calm, light, sage green, soft blue, teal, cream. Legal and finance: sober, navy, dark green, classic serif. Beauty: elegant, sand tones, dusty rose, black with gold.
- **Images:** the space and the atmosphere (calm treatment room, modern clinic interior, law office books, beauty salon interior). No identifiable patients or clients in sensitive situations.
- **Several pages when:** many services with long descriptions (a clinic with 10+ treatments). Then: main page plus one page per group of services.
- **Form note:** a contact form needs an external service that sends the emails (Formspree or Web3Forms, both have a free tier). The user creates an account there and gives you the form address or public key. Say this plainly before they choose it.

## 6. Company

- **Keywords:** company, business, firm, agency, factory, distributor, b2b, manufacturer, logistics, construction, software, studio
- **Voice:** first person plural ("we build", "we deliver").
- **Actions:** 1) Request a quote (email) 2) Book a call 3) Call 4) Contact form through an external service (see the note in type 5) 5) Write my own
- **Questions:**
  1. What does the company do, in one sentence, and for whom?
  2. Which products or services do you offer? (3-8, one sentence each)
  3. What kind of clients do you serve, and which well-known clients can you name (with their permission)?
  4. A few real figures, if they should appear (founding year, number of projects, team size).
  5. How do you work with a new client, step by step?
  6. The team: should people appear on the site? (name, role, photo)
  7. Office address, hours, company registration details (if wanted in the footer).
  8. Case studies or client testimonials?
- **Sections:** Top bar · Hero (what you do + action) · Client logos (if any) · Services / products · How we work · Why us · Figures (real ones only) · Case studies / testimonials · Team (if wanted) · FAQ · Contact · Footer (with company details)
- **Mood:** professional, clear, confident. Colors come from the field and the logo, if any. Industrial: grey, orange, yellow. Tech: dark background, cool accent. Finance: navy, dark green.
- **Images:** the company's field (modern office team, warehouse logistics, construction site, factory production line)
- **Several pages when:** many different services with long descriptions, or detailed case studies. Then: main page plus one page per service or case study.

## 7. Product / launch

- **Keywords:** product, launch, landing, app, startup, gadget, book, game, preorder, waitlist, kickstarter
- **Voice:** first person plural, or direct to the customer ("you").
- **Actions:** 1) Buy (external link: store, Stripe Payment Link, Gumroad, Amazon) 2) Join the waitlist (external form: Tally, Google Forms, a newsletter provider) 3) Download the app (App Store / Google Play) 4) Preorder (external link) 5) Write my own
- **Questions:**
  1. What's the product, and which problem does it solve?
  2. Who is it for?
  3. 3-5 things it does, or concrete benefits?
  4. How does it work, in 3 steps?
  5. Price and where to buy it (or the launch date)?
  6. Photos, renders or a video of the product?
  7. Feedback from early users, press, or real figures?
  8. Questions people often ask about it.
- **Sections:** Top bar · Hero (the product large + the promise + button) · The problem · How it works (3 steps) · What it does (benefits with icons) · Photos / video · Feedback (if any) · Price or offer · FAQ · Final call · Footer
- **Mood:** the product decides. Dynamic, strong contrast, one memorable accent. Tech: dark background with an electric accent. Consumer: bright, rounded, friendly. Premium: black, white, one metal.
- **Images:** the product itself is essential; without it, context images (lifestyle product flat lay, hands holding phone app, minimal product studio)
- **Several pages when:** rarely. Maybe a separate FAQ or pricing page for complex products.
- **Note:** a cart, customer accounts, or payment directly on the site are advanced features (see `advanced-features.md`). An external store link or Payment Link is the simple option.

## 8. Nonprofit / cause

- **Keywords:** nonprofit, ngo, charity, foundation, association, cause, volunteer, donation, community, shelter, campaign
- **Voice:** first person plural, warm and concrete.
- **Actions:** 1) Donate (external link: their donation platform, PayPal, Stripe Payment Link) 2) Volunteer (external form or email) 3) Contact us 4) Write my own
- **Questions:**
  1. What does the organization do, and for whom?
  2. Since when, and who's behind it?
  3. Current projects or programs? (name, what you do, real results)
  4. How can someone help? (money, time, goods)
  5. Donation details: donation link, bank details (if they should appear), registration number.
  6. Real figures about your work? (people helped, volunteers)
  7. Real stories (with consent) and photos from your activities.
  8. Partners or sponsors to mention.
- **Sections:** Top bar (with Donate) · Hero (the cause + donation button) · The problem we tackle · What we do (programs) · Results (real figures only) · Stories · How you can help (donate / volunteer) · Partners · Transparency (annual reports, if any) · Contact · Footer (organization details)
- **Mood:** human, warm, hopeful. Full, friendly colors: green, warm orange, yellow, light blue, terracotta. Rounded fonts or a warm serif.
- **Images:** community and help (volunteers helping, community garden, animal shelter dog). Avoid images that exploit suffering.
- **Several pages when:** several programs with long stories, or a separate reports page.
- **Note:** processing payments directly on the site is an advanced feature. A link to the donation platform is the simple option.

## 9. Event

- **Keywords:** event, conference, wedding, party, concert, festival, workshop, course, seminar, meetup, launch, competition, webinar
- **Voice:** direct to the guest ("join us", "see you there") or first person plural (organizers).
- **Actions:** 1) Buy a ticket (external link: Eventbrite or similar) 2) RSVP (external form: Google Forms, Tally) 3) Register (external form) 4) Join the waitlist 5) Add to calendar 6) Write my own
- **Questions:**
  1. What's the event, its name, and who is it for?
  2. Date, time and place (exact address), or the online link.
  3. The schedule, by the hour, if there is one.
  4. Who speaks, performs or presents? (name, one sentence, photo)
  5. Tickets or registration: price and link.
  6. Practical info (parking, accommodation, dress code, what to bring).
  7. Organizers, partners, sponsors.
  8. For a wedding: your story, the gift registry (link), accommodation for guests.
- **Sections:** Top bar · Hero (name, date, place, button, countdown) · About the event · Schedule · Speakers / guests · Location (with a map) · Tickets / registration · Practical info · FAQ · Partners · Footer
- **Mood:** the event's tone. Conference: energetic, contrast, big type. Wedding: delicate, cream, sage, gold, elegant serif. Concert and festival: dark, vivid colors, bold fonts.
- **Images:** the kind of event (conference stage audience, wedding table flowers, concert crowd lights, workshop people laptops)
- **Several pages when:** a multi-day festival with several stages, or a conference with a page per speaker.
- **Note:** the countdown runs in the browser, with no server. After the date, show "This event has taken place" instead of negative numbers.

## 10. Restaurant / café / bar

- **Keywords:** restaurant, cafe, café, bistro, bar, pizzeria, bakery, patisserie, food truck, inn, terrace, winery, brewery
- **Voice:** first person plural, with appetite.
- **Actions:** 1) Book a table (phone or their booking platform link) 2) Call 3) Order online (delivery platform or own ordering link) 4) See the menu 5) Get directions (map) 6) Write my own
- **Questions:**
  1. The name, and what kind of food or drink you serve?
  2. What makes you different? (family recipes, coffee you roast yourselves, local produce only)
  3. The menu: categories, dishes, prices (a photo or PDF of the menu works).
  4. Address and opening hours by day.
  5. Bookings and orders: phone, delivery links.
  6. Photos of the food and the place.
  7. Events, daily specials, brunch, live music?
  8. Customer reviews, or your Google rating.
- **Sections:** Top bar (with Book) · Hero (large image of food or the place) · Our story · Menu (by category, with prices) · Gallery · Events or specials (if any) · Reviews · Hours and location (with a map) · Book / order · Footer
- **Mood:** appetizing and warm. Warm tones (terracotta, mustard, olive green, cream), or dark and elegant for a bar or fine dining. A serif with personality, or handwritten fonts for headings, in moderation.
- **Images:** the food and the atmosphere (rustic food table, coffee latte art, cozy restaurant interior, wood fired pizza). Their own photos are much better; tell them.
- **Several pages when:** a long menu (more than 30 items) or a separate events page. Then: main page plus a menu page.
- **Note:** the menu is written as text, never as an image, so it reads on a phone and search engines can find it.

## 11. Creator (course, newsletter, podcast, channel)

- **Keywords:** creator, influencer, youtuber, podcast, newsletter, online course, instructor, author, writer, blogger, streamer, musician
- **Voice:** first person singular, with personality.
- **Actions:** 1) Subscribe to the newsletter (provider form: Substack, MailerLite, Kit, Brevo) 2) Follow the channel (YouTube / TikTok / Instagram) 3) Listen to the podcast (Spotify / Apple Podcasts) 4) Buy the course (external link to the course platform) 5) Work with me (email) 6) Write my own
- **Questions:**
  1. What do you create, and about what?
  2. Who do you create for?
  3. Where do you publish, and what are the links?
  4. Your best 3-6 pieces? (episodes, videos, articles; links)
  5. Do you sell something? (course, book, consulting, products) Price and where?
  6. Real figures to show (subscribers, listens, students).
  7. Feedback from students or followers.
  8. A few lines about you.
- **Sections:** Top bar · Hero (who you are + subscribe) · About · Best pieces (cards with links) · What I offer (course, book, collaborations) · Feedback · Newsletter signup · Contact for collaborations · Footer (networks)
- **Mood:** the creator's personality. It can be bold: high contrast, one strong accent, expressive fonts. For education: clear, friendly, bright.
- **Images:** the creator's photo is essential; context (podcast microphone studio, camera setup creator, notebook writing desk)
- **Several pages when:** a separate page for a course or book, or an episode archive.
- **Note:** members-only paid content is an advanced feature (see `advanced-features.md`). A link to the course platform or Patreon is the simple option.

---

## New site type (when "Write my own" matches nothing)

It's fine for the user to want something not on the list (a site for their dog, a memorial page, a school theater group). Build the type on the spot, with the same structure:

1. **Voice:** who speaks on the site, and to whom.
2. **Actions:** 3-5 things a visitor can do, all possible without a server (phone, email, WhatsApp, external link, external form, scrolling to a section). If the only action asked for is an advanced feature, apply `advanced-features.md`.
3. **Questions:** 5-8, specific, numbered, with examples.
4. **Sections:** 6-10, top to bottom, starting with Top bar + Hero and ending with Footer.
5. **Mood and images:** from the subject itself.

At Step 1, tell the user in one sentence how you understood the site ("I'll build it as a quiet, warm memorial site, with his story, photos, and a way for people to send a message by email."). Handle sensitive subjects (memorials, health, children) with care.

## Matching the demo argument

Compare the argument (lowercase) with the keywords above, on whole words (plural forms count: `restaurants` matches "restaurant"), not on fragments of words. The first matching type, in order 1-11, wins. Examples: `demo electrician` → 4, `demo lawyer` → 5, `demo physio` → 5, `demo wedding` → 9, `demo podcast` → 11, `demo cv` → 2. If nothing matches, build a new type on the argument (`demo aquarium` → a site for an aquarium hobbyist, built as a hobby or new type, whichever fits better).

In demo mode, invent believable, clearly fictional content: natural names, a real city, plausible services and prices, no real companies or well-known people.
