# The build (Step 7)

You (the agent) run every command through your own command-line tool. The user never types anything in a terminal.

## Mac, Windows, Linux

- The commands here are Unix style (`mkdir -p`, `rm -rf`, `cp -R`). On Windows, Claude Code runs commands through Git Bash, so they work as written. `npm`, `node` and `git` are the same everywhere.
- File and folder names: lowercase, no spaces (hyphens instead), no accented letters.
- If Node.js or Git is missing, send the user to [nodejs.org](https://nodejs.org) (the LTS version) or [git-scm.com](https://git-scm.com). Installing is a few clicks, the same on Mac and Windows. After they confirm, check again with `node -v` / `git --version`. On Windows, the Claude app may need a restart to see the new commands.

## 1. Versions: always the latest stable

The skill never pins versions. On every run, before installing anything, check the current versions:

```bash
npm view create-vite version
npm view vite version
npm view vite engines.node
npm view react version
npm view @vitejs/plugin-react version
npm view tailwindcss version
npm view @tailwindcss/vite version
npm view gsap version
npm view @gsap/react version
npm view lucide-react version
npm view simple-icons version
```

Always install with `@latest` (see below), so you get the latest stable version.

**Major versions this skill was written against** (October 2026): create-vite 9, Vite 8, React 19, @vitejs/plugin-react 6, Tailwind CSS 4, GSAP 3, @gsap/react 2, lucide-react 1, simple-icons 16.

If a major version you just checked is **higher** than these (Vite 9, Tailwind 5, say), read that package's official setup guide or migration notes on the web before building, and adapt the commands and configuration below. Your memory of these tools may be out of date; the official docs are the source of truth. If you have no web access, install the latest release of the known major (`vite@^8`, for example) and note it in the README under "Technical notes".

**Node.js:** the Node version must satisfy Vite's `engines.node` (for example `^20.19.0 || >=22.12.0`). The recommendation for the user is always the **LTS** version from nodejs.org.

## 2. The project folder

- The site is built **directly in the current folder** (the one Claude Code was opened in), checked as empty at the start (see SKILL.md, "Start: check the folder").
- The project name is the folder name, as a slug (see SKILL.md). Never `one-shot-website` or a generic name.
- At Step 4 you create `temp-safe-to-delete/` in it, for the preview and other temporary files.
- Tell the user once where the site is ("Your site is being built in the lakemont-physio folder you opened.").

## 3. Creating the project

`create-vite` refuses a folder that isn't empty, and without flags it asks interactive questions that block the agent. So you create the scaffold inside the temporary folder, then copy it up:

```bash
mkdir -p temp-safe-to-delete
npm create vite@latest temp-safe-to-delete/scaffold -- --template react --no-interactive --no-immediate
cp -R temp-safe-to-delete/scaffold/. ./
rm -rf temp-safe-to-delete/scaffold
```

In `package.json`, set `"name"` to the project name.

If `--no-interactive` or `--no-immediate` no longer exists in the current version (the command fails or stops at a question), run `npm create vite@latest -- --help` and use the equivalent flags.

**Install:**

```bash
npm install
npm install react@latest react-dom@latest
npm install tailwindcss@latest @tailwindcss/vite@latest
npm install gsap@latest @gsap/react@latest lucide-react@latest
```

Only if the site has links to social networks or WhatsApp:

```bash
npm install simple-icons@latest
```

**Clean the template:**

```bash
rm -f src/App.css
rm -rf src/assets
rm -f public/icons.svg
```

Warnings about `install-scripts` during `npm install` (for `fsevents`, say) are harmless; ignore them.

- The template's `public/favicon.svg` is purple: replace it with a simple SVG in the chosen direction's colors (the name's initial on a rounded square in the accent color, or a simple shape tied to the field). If the user has a logo, the favicon can be based on it.
- Rewrite `src/App.jsx`, `src/main.jsx`, `src/index.css`, `README.md` and `index.html` completely.
- Keep `.oxlintrc.json` and the `lint` script if the template includes them.

**Copy the user's files** (from Step 3 or from the brief): the logo into `public/` (`public/logo.svg` or `public/logo.png`), photos into `public/images/` with simple names (`team-1.jpg`, `treatment-room.jpg`). If a photo is over 1 MB, tell the user the page will load more slowly and that they can send a smaller version. Never modify the user's original files.

**`.gitignore`:** add to what the template has, if missing:

```
node_modules
dist
.vercel
.env
.env.*
.DS_Store
Thumbs.db
desktop.ini
*.local
.claude/
temp-safe-to-delete/
```

`.claude/` is ignored so the skill's own files never end up in the site's repository.

**Git, after cleaning:** as soon as the template leftovers are gone and the new favicon and `.gitignore` are in place:

```bash
git init -q
git add .
git commit -q -m "First commit"
```

No `git push` here; publishing is decided at Step 8. If Git asks for a name and email (`Please tell me who you are`), set them locally, for this project only: `git config user.name "<name on the site>"` and `git config user.email "<the user's email if given, otherwise site@example.com>"`.

## 4. Configuration

**`vite.config.js`** (one page):

```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
})
```

**Several pages:** each page is a folder with its own `index.html` (`about/index.html`, `work/green-house/index.html`), each with its own entry script (`/src/pages/about.jsx`). Declare them in the config:

```js
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { resolve } from 'node:path'

const root = import.meta.dirname

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    rolldownOptions: {
      input: {
        main: resolve(root, 'index.html'),
        about: resolve(root, 'about/index.html'),
      },
    },
  },
})
```

Vite 8 uses Rolldown, so the key is `rolldownOptions` (older versions used `rollupOptions`). Links between pages are normal: `<a href="/about/">`. The result is a static site that works on any host, with no routing settings. Don't use React Router.

**`src/index.css`:**

```css
@import url('https://fonts.googleapis.com/css2?family=<FONTS>&display=swap');
@import "tailwindcss";

@theme {
  --color-page: <base>;
  --color-accent: <accent>;
  --color-ink: <ink>;
  --color-panel: <panel>;
  --color-muted: <muted>;
  --color-on-accent: <buttonText>;

  --font-sans: "<headingFont>", ui-sans-serif, system-ui, sans-serif;
  --font-body: "<bodyFont>", ui-sans-serif, system-ui, sans-serif;
  --font-mono: "<extraFont or JetBrains Mono>", ui-monospace, monospace;
}

html { scroll-behavior: smooth; }
body { background: var(--color-page); color: var(--color-ink); font-family: var(--font-body); }
```

**Watch the names:** never name a color with a word Tailwind uses for sizes (`base`, `xs`, `sm`, `md`, `lg`, `xl`, `2xl`...). `--color-base` would turn `text-base` (the 1rem size) into a color, and text can become invisible. That's why the background is called `page`.

Classes: `bg-page`, `bg-accent`, `text-on-accent`, `text-ink`, `text-muted`, `bg-panel`, `font-sans`, `font-body`, `font-mono`. The `@import url(...)` for fonts goes **before** `@import "tailwindcss"`.

**`index.html`:** `<html lang="en">` (or the site's language), a `<title>` with the business name and what it does (for example "Lakemont Physio | Physiotherapy in central Lakemont"), a `<meta name="description">` under 155 characters that names the services and the city in plain words, Open Graph tags (`og:title`, `og:description`, `og:image` with the hero image), the favicon, and the viewport meta tag (section 6b).

## 5. Architecture

```
src/
├── main.jsx
├── App.jsx              ← places the sections one under the other, only those in the plan
├── index.css
├── data/site.js         ← ALL editable content: name, contact, links, texts, lists
└── components/
    ├── TopBar.jsx
    ├── Hero.jsx
    ├── <one component per section in the plan>.jsx
    ├── BrandIcon.jsx     ← only if there are social links
    └── Footer.jsx
```

- **`src/data/site.js`** holds all the data (contact, texts, services, projects, FAQ, links) in one place, so the user (or the README) can say exactly "change it here". Components read from it.
- Component names follow the plan's sections in English (`TrustStrip.jsx`, `Services.jsx`, `WhyUs.jsx`, `HowItWorks.jsx`, `Area.jsx`, `Testimonials.jsx`, `FAQ.jsx`, `FinalCall.jsx`, `Menu.jsx`, `Schedule.jsx`).
- **Placeholders:** where the user has no logo, photo or testimonial yet and asked for a slot, leave a clearly marked slot. In the code, mark it with a comment that starts with `SWAP:` (for example `{/* SWAP: replace with your own photo in public/images/ */}`), and in `site.js` give the field a `// SWAP:` comment. Every stock image placed on the site also gets a `// SWAP:` comment, so replacing it later takes minutes. The README lists every `SWAP:` spot.
- **Testimonials:** only those the user provided, with the names exactly as given. If the user asked for empty slots, render the section only if they asked for it to appear, with marked slots.

**Icons:**
- `lucide-react` for general icons (`Phone`, `Mail`, `MapPin`, `Clock`, `Calendar`, `Heart`...). Check that a name exists before using it (`node -e "console.log('Phone' in require('lucide-react'))"`).
- **lucide-react 1.x has no brand icons** (Instagram, Facebook, GitHub, YouTube, LinkedIn). For those, use `simple-icons`: `import { siInstagram } from 'simple-icons'` and draw `<svg viewBox="0 0 24 24"><path d={siInstagram.path} /></svg>` (in `BrandIcon.jsx`, with `fill="currentColor"`). Import only the icons you use, by name.
- **LinkedIn is not in simple-icons either** (removed at the brand's request). Show it as text ("LinkedIn") or as a rounded square with the letters "in" in the heading font.

**Action links:**
- Phone: `tel:+40356000000` (international format, no spaces). Displayed nicely: `+40 356 000 000`.
- WhatsApp: `https://wa.me/40356000000` (no `+`, no leading `0`), optionally `?text=` with a short, encoded message.
- Email: `mailto:`.
- External links (bookings, donations, store, tickets): `target="_blank" rel="noopener noreferrer"`. A link given without a protocol (`cal.com/lakemont`) becomes `https://cal.com/lakemont`.
- Map (if there's an address): `<iframe src="https://www.google.com/maps?q=<encoded address>&output=embed" loading="lazy">`, no API key.
- Form through an external service (Formspree / Web3Forms): the form address or public key goes in `src/data/site.js`. These are not secrets (they appear in the published page anyway); a secret key has no place in a static site (see `advanced-features.md`).

## 6. Visual rules, on every site

- **The primary action** (from Step 2) appears **at least 4 times**: in the top bar, in the hero, at one point mid-page (after the services, or in the area or how-it-works section), and in the final call. For tradespeople, the phone button also appears at least 4 times.
- **TopBar:** fixed at the top, rounded corners, transparent at first; on scroll it gets a blurred background (`backdrop-blur-xl`) and a thin bottom line (in the accent if the accent has at least 3:1 against the background, otherwise `border-ink/15`). Name or logo on the left, 3-5 links to sections, the main button on the right. Hamburger menu on mobile. Links scroll smoothly.
- **Hero:** `min-h-dvh`, an image that fits the mood (with a dark overlay if text sits on it), a large heading with one word in the accent, one sentence, the buttons. For a portfolio or product, the work or the product is the image.
- **Cards:** `bg-panel`, `rounded-2xl`/`rounded-3xl`, a subtle border; on hover a slight lift and the border in the accent (or `border-ink/30` if the script warned that the accent is below 3:1).
- **Buttons:** `bg-accent text-on-accent`, hover `scale-[1.02]`, press `scale-[0.97]`, smooth transitions, at least 44px tall on mobile.
- **Texture:** a very faint noise layer (SVG `feTurbulence`, opacity 0.03-0.05) over the page, so flat backgrounds don't look sterile.
- **GSAP animations:** only through `useGSAP` from `@gsap/react` (automatic cleanup), `power3.out`, scroll reveals with `ScrollTrigger` (`gsap.registerPlugin(ScrollTrigger, useGSAP)`). Put the animations inside `gsap.matchMedia()` with `(prefers-reduced-motion: no-preference)`, so people who asked for less motion see the content directly. No animation may leave content invisible if it doesn't run.
- **Accessibility:** descriptive `alt` on images, contrast from `check-palette.mjs`, visible focus on buttons and links, headings in order (`h1` only once).
- **Unsplash images:** real URLs (`https://images.unsplash.com/photo-<ID>?w=2000&q=80`). **How to find them:** the Unsplash API and search pages need authentication (`curl` gets 401), so search with your web search tool (for example "unsplash calm physiotherapy treatment room") and read the photo page you find (`unsplash.com/photos/...`) to get the `images.unsplash.com/photo-...` address. Check each one with `curl -sI <url>` (it must return `200` and `content-type: image/...`) and **actually look at it** (download it into `temp-safe-to-delete/` and view it, if you can read images). No images with text, signs or plates in a language other than the site's, no company logos, no identifiable people in sensitive situations. Never guess IDs from memory without testing them.
- **Countdown** (events): calculated in the browser; after the date, show "This event has taken place".
- **Current year** in the footer, calculated once at module level, outside the component (`const year = new Date().getFullYear()`); inside the component, Oxlint warns.
- **Icons and currency:** some lucide icons contain a "$" sign (`Receipt`, `BadgeDollarSign`, `CircleDollarSign`). For prices in other currencies, use neutral icons (`Tag`, `Wallet`, `FileText`, `Coins`).
- **Mobile first:** everything reads well from 375px, nothing goes off-screen, no text is cut off. The concrete rules are in section 6b and the automatic check in section 8.

## 6b. Mobile: required rules

Write the classes for the 375px screen first, then add `sm:`, `md:`, `lg:` for larger screens.

- **Viewport meta** in `index.html`: `<meta name="viewport" content="width=device-width, initial-scale=1.0" />`. Without it, the phone shows the page shrunk, like on a desktop.
- **Text:** reading text is at least 16px on mobile (`text-base`); nothing visible under 12px (labels, notes, footer: at least `text-xs`). Never shrink text to make it fit; let it wrap.
- **Tap targets:** action buttons and links are at least 44px tall (`min-h-11` / `min-h-12`, icon buttons `size-11`). Menu and footer links get `py-2` or `inline-block py-2`, to get close to 44px. Nothing under 24px (the WCAG 2.2 minimum).
- **Buttons:** `whitespace-nowrap`, so the text never breaks across two lines; on mobile they stack, full width (`flex-col sm:flex-row`, `w-full sm:w-auto`). If a button's text doesn't fit, shorten it.
- **Grids:** text cards sit in one column on mobile (`grid gap-4 sm:grid-cols-2 lg:grid-cols-3`). Two columns on a phone only for very short items (figures, logos, icons with 2-3 words).
- **Large headings:** `text-balance`, size limited on small screens (`text-4xl sm:text-5xl lg:text-7xl`, or `text-[min(52vw,38dvh)]` for one huge word). Multi-line headings get `leading` of at least `1.1` (`1.15` for condensed uppercase fonts), so accents and descenders don't collide with the next line. A huge word gets room above (`pt-[0.2em]`) and below, and nothing below it (tilted strips, overlapping cards) may cover it.
- **Prices, phone numbers, codes:** `whitespace-nowrap` (`$45`, `+40 356 000 000`). Hyphenated words that must not break (USB-C) get a non-breaking hyphen (U+2011).
- **Hidden on mobile, visible on desktop:** never combine `hidden` with a display class the component adds on its own (an `inline-flex` added by default by a button component). The class written last in the CSS wins and the element stops hiding. The button component must not add its display class when it receives `hidden` in `className`.
- **Menu:** hamburger below `lg`, with a button of at least 44px; the open menu has large links and the main button at full width, and closes when a link is clicked.
- **Desktop-only effects:** anything that depends on a cursor (an image that follows the mouse, a hover that reveals info) appears only from `lg:` and never hides important information. On a phone, the same information is visible directly.
- **Pinned sections and horizontal scrolling** (`ScrollTrigger` with `pin`): desktop only, inside `gsap.matchMedia('(min-width: 1024px) and (prefers-reduced-motion: no-preference)')`. On a phone they become a vertical list or a strip you swipe (`overflow-x-auto snap-x snap-mandatory`).
- **Images and maps:** images have a fixed ratio (`aspect-[4/5]`, `object-cover`) and `loading="lazy"` below the first section; the map has a fixed height on mobile (`h-80`).
- **No large fixed widths:** nothing wider than 335px fixed on mobile (use `w-full`, `max-w-*`). `overflow-x-clip` on the root element is only a safety net; never use it to hide text that goes off-screen.

## 7. The site copy

1. Write all the copy in `src/data/site.js` (and directly in components where needed), in the site's language, in the voice chosen at Step 3.
2. Use only the information the user gave (or the brief). What they didn't give doesn't appear. In demo mode, invented content is marked in the README.
3. Apply the tone words from the brief (for example "calm, specific, unhurried, no ad-speak") to every text.
4. **Check all the copy against `references/writing-rules.md`.** Apply every rule and the final checklist to every visible text: headings, subheadings, buttons, cards, FAQ, footer, `<title>`, meta description, image `alt` text.

## 8. Checking and previewing

```bash
npm run build
```

The build must pass without errors. **Don't stop at the build.** Start the site and look at it:

```bash
npm run dev
```

(in the background; the address is usually `http://localhost:5173`)

- If you have a preview or browser tool, open the site at 375px and on desktop, scroll the whole page, and check the hero, cards, images, footer, the mobile menu, and every page (if there are several).
- If you have no way to see the page, look at the screenshots the script below makes. If the script can't run either (no Chrome, Edge or Chromium), ask the user to open the address in their browser and tell you if anything looks broken.

**The mobile check, required** (with the dev server running):

```bash
node <skill-path>/scripts/check-mobile.mjs http://localhost:5173 --out temp-safe-to-delete --name site
```

The script starts the installed Chrome (or Edge/Chromium) without a window, and:
- takes two screenshots, only what's visible on load: `temp-safe-to-delete/site-desktop.png` (1440×900) and `site-phone.png` (a phone screen). **Look at both.**
- checks the page at 375px: horizontal scrolling, cut-off text or buttons, buttons and links under 24px (a problem) or under 44px (a warning), text under 12px, the viewport meta tag, content still invisible after scrolling, images that don't load.

Exit code 0 means it passed. On code 1, fix everything under `problems` and run it again until it passes. Fix `under44pxWarning` items if they're action buttons (the logo, or an email link on a full line, can stay). If you test in a browser with your own scripts, use `window.scrollTo({ top: y, behavior: 'instant' })`: with the page's smooth scrolling, the scroll never reaches its position, the animations don't start, and content seems to be missing.

Fix whatever is broken (an image that doesn't load, cut-off text, content invisible because of animations, a wrong color), rebuild, look again.

At the end, tell the user plainly: "The site is running on your computer at http://localhost:5173. Open that address in your browser to see it." and a 3-5 line summary of what you built.

Commit the finished site: `git add . && git commit -q -m "Site built"`.

## 9. Checklist before Step 8

- [ ] Versions checked with `npm view`, packages installed with `@latest`
- [ ] Vite template cleaned; `favicon.svg` in the direction's colors
- [ ] `.gitignore` contains `temp-safe-to-delete/`, `.claude/`, `.env`, `node_modules`, `dist`
- [ ] `git init` and the first commit done after cleaning the template
- [ ] Tailwind v4: `@import "tailwindcss"` + `@theme` in `index.css`, the `@tailwindcss/vite` plugin in the config, no `tailwind.config.js`
- [ ] The chosen direction's colors and fonts are in `@theme`; the fonts in `@import` match
- [ ] One page or several, exactly as in the plan; no React Router
- [ ] The sections are exactly those in the plan; sections without content are missing from the page and the menu
- [ ] The primary action appears at least 4 times, with real links
- [ ] External links open in a new tab; `tel:`, `wa.me`, `mailto:` are correct
- [ ] Brand icons from `simple-icons`, LinkedIn as text
- [ ] All editable data is in `src/data/site.js`; every stock image and empty slot has a `SWAP:` comment
- [ ] `<html lang>`, `<title>` with the business name, meta description, Open Graph filled in
- [ ] No unsupported claim (figures, licenses, testimonials only from the user; in demo mode, marked)
- [ ] All copy checked against `writing-rules.md`
- [ ] Unsplash images checked with `curl -sI` and looked at
- [ ] Animations through `useGSAP`, with `prefers-reduced-motion` respected
- [ ] `npm run build` without errors
- [ ] The mobile rules in section 6b followed
- [ ] `check-mobile.mjs` passes (code 0) and you looked at the desktop and phone screenshots
- [ ] The site actually looked at, at 375px and on desktop
- [ ] No advanced feature slipped in without the user's agreement (see `advanced-features.md`)
