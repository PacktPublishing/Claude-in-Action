# Writing rules for the site copy

These rules are part of this skill. Apply them to every visible text on the site before the build check: headings, subheadings, buttons, cards, FAQ questions and answers, testimonial intros, footer, `<title>`, meta description, and image `alt` text. Apply them again to any new text written after the build.

The goal: copy that sounds like the business owner wrote it on a good day. Plain words, concrete facts, short sentences, the visitor's own vocabulary.

## How to apply them

1. Write the copy from the user's answers or brief.
2. Go through the rules below, then the final checklist.
3. Fix only what breaks a rule. A sentence with no problem stays exactly as it is.
4. Never fix a rule by inventing a fact. If a sentence needs a detail the user didn't give, cut the sentence.

## Rules for a website

1. **Headings and buttons are short and concrete.** "Book an assessment", never "Discover the experience". A heading says what the visitor gets or what the business does: "Physiotherapy for back pain, in central Lakemont", never "Your journey to wellness starts here".
2. **Speak the visitor's language.** Use the words a customer would type into a search box or say on the phone: "back pain", "after surgery", "the sink is leaking". Name the services and the city in plain words; that's also how search engines match a local business.
3. **No unverifiable superlatives.** No "the best in town", "world-class", "leading", "unmatched", "premier". Replace them with the fact behind them (years, license, a specific guarantee), or cut them.
4. **No em dashes or en dashes** (— or –) anywhere in the copy. Use a comma, a colon, a period, or rewrite the sentence. Hyphens in words (45-minute, post-surgery) are fine.
5. **No false binaries.** No "It's not X, it's Y" or "Not just X, but Y". Say what it is.
6. **No AI vocabulary.** Verbs: delve, leverage, harness, unlock, empower, elevate, foster, streamline, embark. Nouns: journey (metaphorical), realm, landscape (metaphorical), tapestry, myriad, game-changer. Adjectives: robust, seamless, vibrant, comprehensive, holistic, transformative, cutting-edge, pivotal, innovative. Phrases: "in today's fast-paced world", "unlock your potential", "take it to the next level". Use the plain word or cut it.
7. **No formulaic connectors.** No "Furthermore", "Moreover", "In conclusion", "It's important to note", "Notably", "At its core". Delete them.
8. **No empty virtue adjectives.** "Real results", "true care", "authentic experience", "genuine service", "honest advice": delete the adjective or replace it with the specific thing.
9. **No empty abstract nouns.** "Excellence", "quality", "value", "solutions", "peace of mind", "impact": replace them with what the visitor sees or gets ("a written home program after every visit").
10. **No chains of punchy fragments.** "Fast. Reliable. Local." is a template. Write one full sentence; one short fragment as an accent is allowed per page section.
11. **No curiosity gaps or teasers.** No "The secret to...", "Here's why...", "What makes us different?" as a heading followed by vague answers. State the thing.
12. **No fake candor.** No "Let's be honest", "Here's the thing", "Truth is".
13. **No manufactured lessons.** No tails like "because your health deserves it" or "which makes all the difference". End the sentence at the fact.
14. **No personified tools or things.** The clinic doesn't "care", the program doesn't "walk you through", the website doesn't "welcome you". People do things; say who.
15. **No mood-only words.** "Quietly", "effortlessly", "simply", "truly", "seamlessly": delete them unless they state a fact.
16. **No invented figures or social proof.** Numbers, ratings, client counts, awards and testimonials come only from the user. No "hundreds of happy clients" unless the user gave the number.
17. **Every claim is checkable.** Years, licenses, hours, prices and guarantees match the user's answers exactly.
18. **Calls to action are verbs.** "Book an assessment", "Call now", "Get directions". The same action keeps the same words everywhere on the page.
19. **FAQ answers start with the answer.** "No. You can book an assessment directly." never "Great question! Many people wonder...".
20. **Respect the voice.** "I" everywhere for a solo business, "we" for a team. Never mix them.
21. **Respect the tone words.** If the brief says "calm, specific, unhurried, no ad-speak", every sentence must pass that test; exclamation marks and hype go first.

## Final checklist

- [ ] Zero em dashes and en dashes in visible text
- [ ] No "It's not X, it's Y" / "Not just X, but Y"
- [ ] No word from the AI vocabulary list
- [ ] No formulaic connector at the start of a sentence
- [ ] No superlative or claim the user didn't give
- [ ] No empty abstract noun or virtue adjective left as a label
- [ ] No chain of fragments (one accent fragment per section at most)
- [ ] No teaser heading, no fake candor, no lesson tail
- [ ] No tool or object doing a human action
- [ ] Every figure, credential, price, hour and testimonial matches the user's input exactly
- [ ] Headings say what the business does or what the visitor gets
- [ ] Buttons are short verbs, and the primary action uses the same words everywhere
- [ ] The services and the city are named in plain words at least once (hero or services, plus `<title>` and meta description)
- [ ] One voice throughout ("I" or "we")
- [ ] The tone words from the brief are respected
- [ ] Sentences that had no problem are unchanged

If any item fails, rewrite once more before the build check.
