# Branding (Step 4)

You generate 5 look directions on the spot, fitted to the user's site. There are no ready-made palettes: each direction starts from what the user said (field, audience, name, tone words from a brief) and from "Mood" in `site-types.md`, then passes the rules below.

## What a direction contains

| Field | What it is | Used in `@theme` as |
|---|---|---|
| `name` | 2-3 evocative words, in the conversation's language (for example "Sage Harbor", "Charcoal and Copper") | - |
| `description` | one sentence for the user, no jargon (for example "Off-white with calm teal, quiet and trustworthy.") | - |
| `base` | page background | `--color-page` (never `--color-base`, see build.md) |
| `accent` | buttons, highlights, links | `--color-accent` |
| `ink` | main text | `--color-ink` |
| `panel` | cards and surfaces | `--color-panel` |
| `muted` | secondary text (optional, recommended) | `--color-muted` |
| `buttonText` | text color on the accent button (from the check script) | `--color-on-accent` |
| `headingFont`, `bodyFont` | from the list below | `--font-sans`, `--font-body` |
| `extraFont` | optional: an italic serif for one dramatic word, mono for figures, script for weddings | `--font-mono` / `--font-drama` |
| `images` | 3-4 Unsplash search terms | - |

## Rules for the 5 directions

1. **Different from each other.** At least one with a light background and at least one with a dark background. The accents differ clearly in hue. Don't make 5 variations of one idea.
2. **Fitted to the user.** At least 3 of the 5 start directly from the type's "Mood" and the tone words the user gave. One or two can be bolder, as a surprise, but still right for the field (no neon on a therapy practice).
3. **No default purple.** Directions you generate use no hue between 245° and 330° (violet, lavender, purple, magenta) in any role, gradient or favicon; it's the color generated sites fall back to most. Coral, dusty rose and burgundy are allowed if they fall outside that range. If the user's own brand colors or logo are purple, respect them: mark that direction with `"allowPurple": true` and the script skips the hue check for it.
4. **Readable contrast** (checked by the script):
   - text on background and text on cards: at least 4.5:1, ideally above 7:1
   - secondary text on background: at least 4.5:1
   - text on the accent button: at least 4.5:1 (the script tells you whether white, black, `ink` or `base` works)
   - if the accent is below 3:1 against the background (yellow on white, say), use it only as a solid surface (button background, strip, badge), never as text, a thin line or a border; make lines and borders from `ink` with transparency (`border-ink/15`)
5. **Fonts only from the list below**, unless the user asks for another one (see "Font outside the list").

## Checking with the script

Write the directions as JSON in `temp-safe-to-delete/directions.json` (a list of objects with `name`, `base`, `accent`, `ink`, `panel`, `muted`) and run:

```bash
node <skill-path>/scripts/check-palette.mjs temp-safe-to-delete/directions.json
```

The script also accepts the preview object directly (`{ "directions": [...] }`), so you can check the same JSON you put in the preview.

- `"ok": true` → move on. Take `buttonTextHex` for each direction as its `buttonText`.
- `"ok": false` → fix what `errors` and `general` say, then run it again. Never show the user a direction that failed.
- `warnings` → respect them in the build (an accent used only as a button background, for example).

## The preview

1. Copy `<skill-path>/assets/branding-preview.html` to `<project>/temp-safe-to-delete/branding-preview.html`.
2. Replace only the content of the `<script id="data" type="application/json">` block with:
   - `siteName`: the name on the site
   - `sampleHeading`: a plausible, short hero heading
   - `sampleText`: one subtitle sentence
   - `button`: the main button text (from Step 2)
   - `directions`: the 5 directions (plus the one taken from a site or requested by the user, if any, with `source`)
3. Open the file in the browser, by system:
   - Mac: `open temp-safe-to-delete/branding-preview.html`
   - Windows (Git Bash): `start "" temp-safe-to-delete/branding-preview.html` (if that fails: `cmd //c start "" "temp-safe-to-delete\branding-preview.html"`)
   - Linux: `xdg-open temp-safe-to-delete/branding-preview.html`
   - If none works, give the user the full path and tell them to double-click the file.
4. Tell the user the page is open and show the menu from SKILL.md, Step 4.

No preview in demo mode.

## Option 6: "I have a site I like"

1. Run:
   ```bash
   node <skill-path>/scripts/extract-colors.mjs <address> --out temp-safe-to-delete/site-colors.json
   ```
2. Read `proposal` (base, ink, accent, panel), `fonts` and `warnings`.
3. **Fonts** found are often proprietary (like "sohne-var" or "GeistSans") or internal names. Match each one to the closest font in the list below and tell the user: "That site uses X, which isn't free; I used Y, which looks very similar."
4. **Colors** pass the same rules. If the accent is purple or the contrast fails, adjust as little as possible (same lightness, hue moved outside the excluded range) and tell the user exactly what you changed and why.
5. Add the direction as number 6 in the preview, with `"source": "from your site"`, and open it again.
6. If the script fails or warns "very few colors" (a site built entirely in JavaScript, or one that blocks downloads), ask the user for a screenshot of the site. If you can read images, take the colors from it; otherwise ask them to describe the main colors.

Take only the colors and the font style from that site, never its logo, text or images.

## Option 7: "I already have colors or a logo"

- **Color codes** (hex, RGB, or names like "navy and orange"): turn them into base/accent/ink/panel, fill in what's missing, check with the script.
- **Logo (image):** if you can read images, take 2-3 dominant colors and build the direction around them (the brightest one usually becomes the accent). If the logo is SVG, read the colors straight from the file. Copy the logo into `public/` during the build.
- The user's own colors keep their hue even if it's purple (set `"allowPurple": true`).
- **From a brief:** if the brief folder has a logo but no fixed colors, use the logo's colors as the starting point for at least two of the 5 directions in the normal menu, and say so in their descriptions. If the brief has fixed brand colors (hex codes or a brand manual), put a direction built exactly from them first, named after the business, and generate four alternatives.

## Option 8: "Write my own"

The user describes it in words ("something elegant, black and gold", "cheerful, for kids"). Build one direction (or 2-3 if the description is vague), check with the script, add them to the preview and ask the user to choose. If the user gives a complete direction (a name, four hex codes and two fonts), use it exactly as given after the script check.

## Font list

**Headings, sans-serif:** Space Grotesk · Sora · Archivo · Plus Jakarta Sans · Bricolage Grotesque · Manrope · Outfit · Syne · Unbounded · Epilogue · Schibsted Grotesk · Hanken Grotesk · Figtree · Onest · Geist · Rubik

**Headings, condensed or poster:** Oswald · Barlow Condensed · Anton · Bebas Neue

**Headings, serif:** Fraunces · Playfair Display · DM Serif Display · Instrument Serif · Young Serif · Cormorant Garamond · EB Garamond · Libre Baskerville · Newsreader

**Body:** Inter · DM Sans · Manrope · Work Sans · Figtree · IBM Plex Sans · Nunito · Barlow · Libre Franklin · Lora · Source Serif 4 · Newsreader · Crimson Pro · Merriweather

**Figures, dates (mono):** JetBrains Mono · Fira Code · IBM Plex Mono · Space Mono

**Handwritten (accents only, in moderation: weddings, cafés, hobbies):** Caveat

**Rounded, friendly (kids, nonprofits, hobbies):** Nunito · Quicksand · Baloo 2 · Rubik

### Pairs that work well (examples, not requirements)

| Style | Headings | Body |
|---|---|---|
| Technical, modern | Space Grotesk | Inter |
| Clean, professional | Plus Jakarta Sans | Inter |
| Warm, with personality | Bricolage Grotesque | DM Sans |
| Editorial, elegant | Fraunces | Newsreader |
| Luxury | Cormorant Garamond | Manrope |
| Sober, legal or finance | Libre Baskerville | IBM Plex Sans |
| Sturdy, industrial | Oswald | Barlow |
| Bold, creator | Syne | Inter |
| Poster, event | Bebas Neue | Work Sans |
| Friendly, community | Rubik | Nunito |
| Wedding | Cormorant Garamond (+ Caveat for accents) | Lora |
| Restaurant | Young Serif | DM Sans |
| Gallery, portfolio | Instrument Serif (italic for accents) | Inter |

### Font outside the list

If the user asks for a font that isn't here, check that it exists on Google Fonts:

```bash
curl -s -A "Mozilla/5.0 (Macintosh) AppleWebKit/537.36 Chrome/126.0" "https://fonts.googleapis.com/css2?family=Font+Name&display=swap" | grep -c "font-face"
```

A result of 0 (or an error) means it isn't on Google Fonts. Tell the user and propose the closest font from the list. If the site is in a language with accented letters, also check for `latin-ext` in the same response.

## The Google Fonts string

In `src/index.css`, during the build, list the chosen families with the weights you use:

```
https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap
```

The rule: spaces become `+`; variable fonts accept any range (`wght@300..800`); for italic in a serif: `family=Instrument+Serif:ital@0;1`.
