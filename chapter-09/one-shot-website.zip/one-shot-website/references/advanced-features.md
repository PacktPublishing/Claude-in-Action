# Advanced features

This skill builds presentation sites: static pages, with no server, no accounts, and no stored data. Some requests cross that line. When they come up, the user has to know before the build, not after.

## Triggers

Any time the user asks for (in Steps 1-6, in a brief, or in a change after the build):

- logins, passwords, a password-protected area, "members only"
- memberships, paid subscriptions, paid content on the site
- payments directly on the site, a shopping cart, checkout, invoicing
- user accounts, profiles, sign-up
- a database, saving what visitors submit on the site
- an admin panel, "so I can edit the content myself in the browser" (a CMS)
- bookings or appointments managed on the site (its own calendar, limited slots)
- comments, a forum, chat between users
- automatic emails, notifications
- any integration that needs a secret API key

These do NOT trigger it: external links (store, bookings, donations, tickets), forms through external services (Formspree, Web3Forms, Tally, Google Forms), an embedded Google map, an embedded YouTube video, a newsletter through the provider's form, a countdown.

## The message (exactly, adapted only to the feature requested)

> **Heads-up:** this skill builds presentation sites, not technical ones. [The feature requested] needs a server, access keys, or a database. I can try to add it, but **at your own risk**: technical questions will come up (servers, API keys, security, costs), and answering them takes programming knowledge.
>
> What should we do?
> 1. **The simple option (recommended):** [the alternative from the table below], with nothing technical.
> 2. **Try it at my own risk:** add the feature; I know technical questions may come up.
> 3. **Drop this feature.**

## Simple alternatives

| The request | The simple option |
|---|---|
| Payments, selling products | A button to a Stripe Payment Link, PayPal, Gumroad, Lemon Squeezy, or the existing store (Etsy, Shopify, Amazon) |
| Cart, store | A separate Shopify or WooCommerce store linked from the site, or one Payment Link per product |
| Donations | A link to the donation platform, PayPal, or a Stripe Payment Link |
| Membership, paid content | Patreon, Memberful, Circle, paid Substack, Skool, linked from the site |
| Online course | The course platform (Teachable, Thinkific, Kajabi, Circle), linked from the site |
| Appointments | Calendly, Cal.com, a Google Calendar booking page, Booksy / Fresha (salons), with a button on the site |
| Restaurant bookings | Phone, WhatsApp, or the booking platform already in use |
| Tickets | Eventbrite or a similar ticketing platform, with a link |
| A form with stored answers | Tally or Google Forms (answers land in the user's account) |
| A "members only" area | A private group (Facebook, WhatsApp, Discord, Circle) with a link |
| Editing content without code | The user asks Claude Code for the change and publishes again; the content sits in `src/data/site.js` |
| Comments | A link to a social post or group |
| Newsletter | The provider's form (MailerLite, Substack, Kit, Brevo), embedded or linked |

## If they choose "Try it at my own risk"

1. **Say up front what they'll be asked for**, concretely for the chosen feature. Examples:
   - payments: a verified Stripe account (with business details), API keys, a small server (Vercel functions), and testing with test cards;
   - login / membership: an authentication service (Clerk, Supabase Auth), a database, access rules;
   - database: a service (Supabase, Neon), access keys, security rules;
   - automatic emails: an email service (Resend), a verified domain.
2. **Secret keys:** only in `.env` (listed in `.gitignore`), never in the code or in `src/data/site.js`. Explain that any variable prefixed with `VITE_` ends up public in the page, so secret keys can be used only in server functions (`api/` on Vercel), never in the browser. On Vercel, keys go in **Settings → Environment Variables**.
3. **Note it in the plan** (`AT YOUR OWN RISK: ...`) and in the README, in an "At your own risk features" section: what you added, which services it uses, where the settings are, what costs can appear, what to test.
4. Build the complete presentation site first, then the advanced feature separately, so the site keeps working if the feature doesn't.
5. When technical questions come up, ask them clearly, one at a time, and say why each answer is needed.

## If they choose the simple option or drop it

Continue the normal flow. The plan shows the simple option chosen (for example "Payments: button to a Stripe Payment Link").
