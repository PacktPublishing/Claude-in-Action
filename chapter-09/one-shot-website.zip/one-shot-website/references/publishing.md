# Publishing (Step 8)

## The order

1. The build passes and the site has been looked at (Step 7).
2. **Ask about publishing before writing `README.md`**, so the README says exactly what happened.
3. Publish (if the user says yes).
4. Write `README.md`: the "site published" version or the "manual steps" version.
5. Ask about a custom domain.
6. Final commit: `git add . && git commit -q -m "README and publishing"` (and `git push` if the repository is on GitHub).

When the skill starts with the `publish` argument, begin here at point 3, on the site in the current folder, then update the README.

## The question

> **Step 8 of 8: Do you want me to put the site online now?** I'll handle it; you won't type any commands. If needed, I'll show you a button to connect your account.
> 1. **Yes**, publish it now.
> 2. **Not now**, keep it on my computer; leave me the steps in the README for later.

A multiple-choice tool is fine here (there are only 2 options).

---

## GitHub + Vercel

GitHub stores the code, Vercel hosts the site, and both have free accounts. Use the connectors first; the command line is the fallback.

### 1. Check the connectors

Look at the tools available to you for GitHub and Vercel connectors.

**If one is missing**, tell the user plainly:

> To publish, I need access to your [GitHub / Vercel] account. In the message box, press the **+** button, go to **Connectors**, and add [GitHub / Vercel]. A page opens where you sign in (you can create a free account there) and press **Authorize**. You do this once. Tell me when it's done.

If they'd rather not use a connector, offer the command-line route (you still run the commands; they only confirm in the browser):
- **GitHub CLI:** check with `gh --version`. If missing, tell them how to install it ([cli.github.com](https://cli.github.com), or `brew install gh` on a Mac, `winget install GitHub.cli` on Windows), then run `gh auth login --web` and let them confirm in the browser.
- **Vercel CLI:** no install needed: `npx vercel@latest login` shows a link or a code; they open it, sign in, and confirm.

If they refuse both, go to "Not now".

### 2. GitHub: a private repository

Create a new repository, **private**, named exactly like the project (the folder name), and push all the code from the local folder.

With the CLI:

```bash
gh repo create <project-name> --private --source . --remote origin --push
```

### 3. Vercel: import and deploy

Import the repository into Vercel as a new project with the same name and trigger the deployment. Vercel recognizes the Vite project on its own; don't change any settings.

If the connector can't create a project or deploy, use the CLI from the project folder:

```bash
npx vercel@latest link --yes --project <project-name>
npx vercel@latest deploy --prod --yes
```

### 4. The one manual step: Connect Git Repository

So that every future code change redeploys on its own, the Vercel project must be linked to its GitHub repository. Check whether it already is (the connector or `npx vercel@latest git connect` may do it). If it isn't, give the user these steps and wait for their confirmation:

> One step needs your hands, once: linking the Vercel project to its GitHub repository, so every change you publish later goes live on its own.
> 1. Open [vercel.com](https://vercel.com) and click the **<project-name>** project.
> 2. Click **Connect Git Repository**.
> 3. If asked, authorize the **Vercel GitHub App** for this repository (or for all repositories).
> 4. Select the **<project-name>** repository and confirm.

### 5. The two addresses

Give the user both:
- the repository: `https://github.com/<account>/<project-name>` (private)
- the live site: `https://<project-name>.vercel.app` (if the name was taken, Vercel adds a suffix; give the real address)

---

## README.md

Always, in this order:

1. **What the site is**, one sentence.
2. **What to replace** (only if needed: demo content, missing photos, empty slots). Point by point, with the file and field: "Open `src/data/site.js` and change `phone`". List every `SWAP:` spot. If nothing is missing, skip this section.
3. **How to use your own photos** (only if stock images are used): put the file in `public/images/`, then in `src/data/site.js` change the image address to `/images/your-photo.jpg`. Or ask Claude Code: "my photos are in this folder, put them in place of the placeholders."
4. **How to see the site on your computer:** "You need Node.js (from nodejs.org). In the site's folder, run `npm install`, then `npm run dev`, and open the address shown (usually http://localhost:5173). Or open the folder in Claude Code and ask it to run the site locally."
5. **How to publish the site:** one of the versions below.
6. **Custom domain** (the text below).
7. **Updates** (the text below).
8. **At your own risk features** (only if the user accepted an advanced feature; see `advanced-features.md`).
9. **Technical notes:** a first line saying "Built with the one-shot-website skill." (the skill uses it to recognize its own projects), then the stack and the versions actually installed (from `npm ls --depth=0`), with the date. The note that the `temp-safe-to-delete/` folder can be deleted at any time. One line: "Vercel's free Hobby plan is meant for personal, non-commercial projects; for a business site, check the current plans at vercel.com/pricing."

The README is in the conversation's language.

### "Site published" version

````markdown
## How to publish the site

The site is already online.

- Live site: **<real address>**
- Code (private): **<GitHub repository address>**
- Hosting: **Vercel**

There's nothing more to do here. For changes, see "Updates" below.
````

### "Manual steps" version (the user chose "Not now")

````markdown
## How to publish the site

**The simplest way:** open this folder in Claude Code and type `/one-shot-website publish`, or just ask "publish this site through my GitHub and Vercel accounts." Claude does the rest.

**By hand:**

**1. Put the code on GitHub.** Create an account at [github.com](https://github.com) if you don't have one, then a new, empty repository at [github.com/new](https://github.com/new). Choose **Private** and don't tick "Add README". Then, in the site's folder:

```bash
git branch -M main
git remote add origin https://github.com/<your-account>/<repository-name>.git
git push -u origin main
```

(The code already has its commits.)

**2. Put the site on Vercel.**

1. Go to [vercel.com/new](https://vercel.com/new) and sign in with your GitHub account.
2. If the repository isn't listed (it's private), click **Adjust GitHub App Permissions** and give Vercel access to it.
3. Pick the repository and click **Import**.
4. Vercel recognizes the Vite project. Don't change anything; click **Deploy**.
5. In a few seconds you get an address like `<project-name>.vercel.app`. The site is online, with HTTPS.
````

### Custom domain (always in the README)

````markdown
## Custom domain (optional)

A domain costs roughly $10 to $20 per year. You have four options; the first is the simplest.

**1. Buy it inside Vercel (recommended)**

1. In your Vercel project, open **Settings → Domains**.
2. Type the name you want (for example `yourbusiness.com`) and click **Buy**.
3. Pay by card, directly in Vercel.
4. The domain connects itself to the site. There are no DNS settings to copy.

**2. Buy it at Porkbun** (often cheaper at renewal)

1. Buy the domain at [porkbun.com](https://porkbun.com).
2. In Vercel: **Settings → Domains**, type the domain, click **Add**.
3. Vercel shows you the DNS records to set: usually an **A record** with the value `76.76.21.21` for `@`, and a **CNAME** with the value `cname.vercel-dns.com` for `www`.
4. In Porkbun, next to your domain, open **DNS** (DNS Records). Add exactly what Vercel shows, and delete any A or CNAME records Porkbun added automatically on `@` or `www`.
5. Wait for Vercel to show **Valid Configuration** (minutes, occasionally a few hours). HTTPS turns on by itself.

**3. Buy it at GoDaddy** (the best known)

1. Buy the domain at [godaddy.com](https://www.godaddy.com). At checkout you can decline the extra products (email, protection, website builder); the domain alone is enough.
2. In Vercel: **Settings → Domains**, type the domain, click **Add**. Keep that page open; it shows the records you need.
3. Sign in to GoDaddy and open your **profile menu → My Products**.
4. Find your domain in the list and click **DNS** next to it (on some screens it's **Manage DNS**, or the domain name, then the **DNS** tab).
5. Find the **A** record with the name **@** (GoDaddy often labels its value "Parked"). Click the pencil (edit) icon, replace the value with the one Vercel shows (usually `76.76.21.21`), and save. If there are several A records on `@`, delete the others.
6. Find the **CNAME** record with the name **www**. Edit it and set the value to the one Vercel shows (usually `cname.vercel-dns.com`), then save. If there's no `www` record, click **Add New Record**, choose **CNAME**, name `www`, value from Vercel, and save.
7. Back in Vercel, wait for **Valid Configuration** next to the domain. It usually takes minutes, occasionally a few hours. HTTPS turns on by itself.

**4. Buy it at Namecheap** (often cheaper at renewal)

1. Buy the domain at [namecheap.com](https://www.namecheap.com).
2. In Vercel: **Settings → Domains**, type the domain, click **Add**.
3. In Namecheap: **Domain List → Manage** next to the domain, then the **Advanced DNS** tab. Add the records Vercel shows and delete any that conflict (the default parking records on `@` and `www`).
4. Wait for **Valid Configuration** in Vercel.

Always use exactly the values shown on your screen in Vercel; the ones above are the usual case.
````

### Updates (always in the README)

````markdown
## Updates

The simplest way: open this folder in Claude Code, describe what you want changed, check it locally, and ask Claude to publish again.

By hand, once the Vercel project is connected to the GitHub repository:

```bash
git add .
git commit -m "What you changed"
git push
```

Vercel redeploys automatically, to the same address, after every `git push`.
````

---

## The domain question (after the README)

> **The site is ready [and online at <address>]. Do you want to put it on your own domain (for example yourbusiness.com)?**
> 1. **Yes**, guide me step by step.
> 2. **Not now**, the steps are in the README.

If they say **Yes**:
- If the site isn't published yet, offer to publish it now (sections above), then switch the README to the "site published" version.
- Propose buying inside Vercel first (the simplest, no DNS). Alternatives: Porkbun or Namecheap (cheaper at renewal) or GoDaddy (the best known).
- Guide them step by step and wait for confirmation after each step. Never buy anything for them: the payment is theirs.
- Domain names: propose 3-5 short options that are easy to say on the phone, without multiple hyphens. If one is taken, propose variants with the city or the trade.

If they say **Not now**, go to the final summary.

### Common domain problems

- **"Invalid Configuration" in Vercel:** usually an old record left at the registrar (two A records on `@`). Delete what isn't from Vercel and copy the values exactly.
- **The site doesn't show up yet:** DNS changes take minutes to a few hours (rarely 48). Force-reload the page (Ctrl+Shift+R / Cmd+Shift+R).
- **You want `yourbusiness.com` to go to `www` (or the reverse):** in Vercel, under Domains, the **Edit** button sets up the redirect.
- **The domain renews yearly:** turn on automatic renewal at the registrar.

---

## Updates requested in the same session

If the site is already published and the user asks for changes: make the change, build, look at it, then:
- **GitHub + Vercel (connected):** commit and push (through the connector or `git push`); Vercel redeploys on its own.
- **Vercel without the Git link:** `npx vercel@latest deploy --prod --yes`, and remind the user of the Connect Git Repository step.
