---
name: one-shot-website
description: A one-page presentation website, ready to go online in an afternoon, without writing code. Builds a complete site for any kind of business or person (service business, clinic, tradesperson, company, product launch, portfolio, personal site, nonprofit, event, restaurant, creator) in 8 short steps with numbered menus, or straight from a prepared brief. Proposes 5 brand directions with a browser preview, builds with React, Vite, Tailwind CSS, GSAP and Lucide at their current versions, checks the page on a phone screen, and publishes through GitHub and Vercel. With the argument "demo" (or "demo restaurant") it builds a full sample site without asking anything. With the argument "publish" it publishes the site in the current folder. Use it when the user asks to build a website, a landing page, a one-page site, a site for their business, or mentions one-shot-website.
metadata:
  version: "1.0.0"
---

# one-shot-website v1.0.0

> A one-page presentation website, ready to go online in an afternoon, without writing code.

You build a presentation website for a user who, most of the time, has never built one. You guide them through 8 steps in plain words, with no technical questions, and deliver a site that runs, works on a phone, and can be published.

## Rules that are not negotiable

1. **Speak to the user in the language they write in** (English by default). The site's own language is chosen at Step 3.
2. **No technical questions.** The user never picks a framework, a host, or a version. Every technical decision is already made here and in `references/build.md`.
3. **Every message in the flow starts with "Step X of 8"**, so the user always knows where they are. Exceptions: the introduction and the final summary.
4. **Menus are numbered text written in the conversation.** Don't put long menus inside a multiple-choice question tool (it accepts few options and breaks long text). Use such a tool, if available, only for short yes/no questions.
5. **Every menu ends with a "Write my own" option**, where the user describes what they want in their own words.
6. **Never invent facts about the user outside demo mode.** Don't offer to invent anything. Invented content exists only in demo mode, and every invented item is marked.
7. **No unsupported claims.** Licenses, years of experience, awards, figures, guarantees and testimonials appear only if the user gave them.
8. **All site copy goes through `references/writing-rules.md`** before the build check (Step 7). These rules are part of this skill; don't call any other skill for this.
9. **The primary action appears at least four times on the page** (top bar, hero, one point mid-page, final call). See `references/build.md`.
10. **Build in the current folder, and only if it's empty.** See "Start: check the folder" below. Never build on top of something else.
11. **Temporary files go in `temp-safe-to-delete/`** inside the project folder, never in hidden folders. That folder is listed in `.gitignore`.
12. **Advanced features trigger the warning** in `references/advanced-features.md` (logins, passwords, memberships, payments on the site, carts, user accounts, databases, admin panels). Check every user answer for them, including change requests after the build.

## Reference files

Read each file when you reach the step that uses it, not all at the start.

| File | When to read it |
|---|---|
| `references/site-types.md` | Steps 1-5: site types, actions, questions, sections, mood |
| `references/branding.md` | Step 4: rules for the 5 directions, fonts, colors from a site, preview |
| `references/build.md` | Step 7: versions, commands, architecture, visual and mobile rules, checklist |
| `references/writing-rules.md` | Step 7, after you write the site copy, and for every later text change |
| `references/publishing.md` | Step 8 and the `publish` argument: GitHub, Vercel, README, domains |
| `references/advanced-features.md` | Whenever an advanced feature comes up |
| `assets/branding-preview.html` | Step 4, the preview template |
| `scripts/check-palette.mjs` | Step 4, contrast check |
| `scripts/extract-colors.mjs` | Step 4, when the user gives a site whose look they like |
| `scripts/check-mobile.mjs` | Step 7, desktop and phone screenshots plus the mobile check |

Paths are relative to this skill's folder. Run the scripts with `node <skill-path>/scripts/<script>.mjs`.

---

## Start: read the argument

The argument is the text after the skill name (for example `/one-shot-website demo`).

- **No argument**, or anything other than the words below: **guided mode**. Check the folder, then the Introduction, then Step 1.
- **`demo`**: **demo mode** with a site type picked at random from `references/site-types.md`.
- **`demo` followed by a type** (for example `demo restaurant`, `demo electrician`): **demo mode** on that type. Match it against the keywords in `site-types.md`. If nothing matches, build a new type exactly for what was asked (see "New site type" in `site-types.md`).
- **`publish`**: skip to Step 8 for the site already built in the current folder. If the folder holds no site built by this skill, say so in one sentence and offer to start a new one.

### Start: check the folder (silently, before the first message)

Run `pwd`, `ls -A`, `node -v` and `git --version` without telling the user.

1. The current folder is the **project folder**. The site is built directly in it. Note its absolute path.
2. **The folder counts as empty** if `ls -A` shows nothing, or only: `.claude/`, `.DS_Store`, `Thumbs.db`, `desktop.ini`, and the zip file this skill was installed from (`one-shot-website.zip`). If that zip is still there, delete it.
3. **If the folder is not empty:**
   - if it already holds a site built by this skill (`package.json`, `src/data/site.js` and a `README.md` that mentions one-shot-website) and the user asks for changes or for `publish`, work on it;
   - otherwise, stop before Step 1. Tell the user, in two sentences, that the skill builds only in an empty folder so it never overwrites anything, and ask them to create an empty folder named after the site (for example `lakemont-physio`), open Claude Code in it, and run `/one-shot-website` again. Don't build anything.
4. If the current folder is the skill's own folder or the root of a drive (`/`, `C:\`), stop the same way.
5. **Project name:** the folder name, made lowercase, with spaces turned into hyphens and any character other than a-z, 0-9 and hyphen removed (`Lakemont Physio` becomes `lakemont-physio`). The same name is used for `package.json`, the GitHub repository and the Vercel project.
6. If Node.js is missing or older than Vite requires (see `references/build.md`), say in the Introduction, plainly, that they need to install Node.js from [nodejs.org](https://nodejs.org) (the LTS version) while they answer the questions, and check again at Step 7. Same for Git ([git-scm.com](https://git-scm.com)).

---

## Demo mode

The user wants to see what the skill does without answering anything.

1. Write one short message: "Starting in demo mode. I'll choose everything and build a complete [type] site. You'll see the result at the end."
2. Go silently through Steps 1-5 as if the user had already chosen:
   - **Step 1:** the type from the argument, or a random one (vary it between runs).
   - **Step 2:** one of the type's primary actions.
   - **Step 3:** invent everything needed, believable but clearly fictional: a business name, a real city, plausible services and prices. Phone numbers use the reserved fictional range `+1 555 0100` to `+1 555 0199`, emails use `example.com`. Site language: English.
   - **Step 4:** generate the 5 directions from `references/branding.md` and pick one at random. No preview.
   - **Step 5:** the type's recommended sections.
3. **Step 6:** show the plan for information only, with everything invented marked `← REPLACE`. Don't ask for confirmation; go straight to the build.
4. **Step 7:** build normally, with every check.
5. **Step 8:** here you **ask** whether to publish. Publishing puts something online under the user's accounts, so never do it without their yes, even in demo mode.
6. The README lists everything invented that has to be replaced.
7. Final summary.

The "Step X of 8" numbering also appears in demo mode, at Steps 6, 7 and 8.

---

## Introduction (guided mode, before Step 1)

> **one-shot-website v1.0.0**
> *A one-page presentation website, ready to go online in an afternoon, without writing code.*
>
> I'll ask you a few things in 8 short steps, nothing technical. You'll see the site before we finish, and at the end I'll help you publish it (or leave you the steps in writing for later). If you already have a brief, tell me where it is and I'll take the answers from there.

Add here, if needed, the line about missing Node.js or Git. Then, in the same message, Step 1.

---

## Working from a brief (any time before Step 4)

If the user points you to a brief, a folder, or files (for example "my brief, logo, and photos are in the lakemont-site folder next to this one"):

1. Read everything there: the brief (`.md`, `.txt`, `.docx`, `.pdf`), any testimonials file, the logo, brand notes, and the list of photos. Claude Code may ask the user for permission to read a folder outside the project folder; tell them to allow it.
2. Map what you find onto the answers for Steps 1, 2 and 3: site type, primary action and its link or number, name, contact, language, services or offerings, reasons to choose them, credentials, hours, area, testimonials, tone words. Treat only what the brief says as fact (Rule 7).
3. Copy the files the site will use into the project: the logo into `public/`, photos into `public/images/` with simple names (`team-1.jpg`, `room.jpg`). Do this at Step 7 if the project isn't created yet, and note the source paths.
4. Ask only for what is missing and needed: the name, the contact behind the primary action, and the voice ("I" or "we") if the brief doesn't make it clear. Put these in one numbered message headed "Step 3 of 8". If nothing is missing, say in one sentence what you took from the brief.
5. Then continue with Step 4. Steps 4, 5 and 6 run normally, with their menus.

---

## Step 1 of 8: What kind of site

Read `references/site-types.md`. Show the menu:

> **Step 1 of 8: What kind of site do you want?**
> 1. Portfolio (designer, photographer, developer, artist)
> 2. Personal site or online résumé
> 3. Hobby or passion (travel, collection, club, sport)
> 4. Trade services (electrician, plumber, painter, carpenter...)
> 5. Professional services (clinic, salon, consultant, lawyer, therapist)
> 6. Company
> 7. Product or launch
> 8. Nonprofit or cause
> 9. Event (conference, wedding, concert, course)
> 10. Restaurant, café or bar
> 11. Creator (online course, newsletter, podcast, channel)
> 12. **Write my own:** describe the site in a few words.
>
> Already have a brief? Tell me where it is instead.

**If they pick "Write my own":** read the description. If it clearly matches a type, say "I'll build it as a [type] site" and continue with it. If it doesn't, that's fine: build a new type exactly on their description (see "New site type" in `site-types.md`) and say in one sentence which sections you'll propose.

Check the description for advanced features (Rule 12).

## Step 2 of 8: What visitors should do

Show the type's primary actions (3-5, from `site-types.md`), numbered, plus "Write my own". A contact form through an external service appears as an option only where it makes sense, with the note from `site-types.md`.

> **Step 2 of 8: What should a visitor do on the site?** Pick one main action (you can add a secondary one).

The primary action becomes the main button, repeated down the page (Rule 9).

## Step 3 of 8: About you or the project

In a single message, numbered, with examples:
- the common questions from `site-types.md` (name, contact for the chosen action, site language, voice, photos, logo, social links)
- the type's specific questions

Every question with options ends with "Write my own". Never offer to invent answers.

If the user skips a question:
- **essential** (the name, the contact for the primary action): ask once more, briefly;
- **not essential**: leave that part out of the site and say so in the plan.

## Step 4 of 8: The look

Read `references/branding.md` and follow it. In short:

1. Generate **5 directions** that fit what the user told you (not only the site type), checked with `scripts/check-palette.mjs`.
2. Create `temp-safe-to-delete/` in the project folder, write the preview to `temp-safe-to-delete/branding-preview.html`, and open it in the browser.
3. Show the menu:

> **Step 4 of 8: How should the site look?** I've opened a page with the options so you can see the colors.
> 1-5. [Direction name]: [one sentence]
> 6. **I have a site I like:** give me the address and I'll take its colors and fonts.
> 7. **I already have colors or a logo:** write the colors or give me the logo file.
> 8. **Write my own:** describe how it should look.

For 6, 7 or 8, build the requested direction using the rules in `branding.md`, add it to the preview, and ask for confirmation.

## Step 5 of 8: The sections

Propose the type's recommended sections (from `site-types.md`), adjusted to the answers from Step 3: sections with no content disappear.

**One page or several:**
- By default, **one page** that scrolls, if everything the user asked for fits on it reasonably.
- If it doesn't fit (a portfolio with many projects, each with its own story and gallery; a hobby blog with several articles; a restaurant with a long menu and an events page), propose several pages, say why, and list them.

> **Step 5 of 8: Which sections go on the site?** Here's what I recommend, from top to bottom. Tell me if we should remove or add anything.
> 1. [section]: [one sentence on what it contains]
> ...
> **Write my own:** add, remove, or reorder.

## Step 6 of 8: The plan

Write the plan as normal text in the conversation, inside a code block, **never** inside a question tool (line breaks get lost and the box becomes unreadable). Ask for confirmation separately, with one short question: "Shall I build the site like this, or change something?"

Keep the lines in exactly this order, with the labels aligned:

```
════════════════════════════════════
STEP 6 OF 8: SITE PLAN
════════════════════════════════════
Site type:      [type]
Name on site:   [name]
Site language:  [language]
Action:         [primary action] ([link or number])
Contact:        [what appears on the site]
Voice:          [I / we]
LOOK: [direction name]
  Background / Accent / Text / Cards:
  [hex] / [hex] / [hex] / [hex]
  Fonts: [headings font] + [body font]

Links:          [social links / none]
Own photos:     [yes / no, I'll place matching images]
[fields specific to the site type]
PAGES:          [one page / list of pages]
SECTIONS (top to bottom):
  1. ...
  2. ...

[only if needed] AT YOUR OWN RISK: [the advanced feature accepted]
[demo only] Everything marked ← REPLACE is invented.
════════════════════════════════════
```

If the primary action has a secondary one, write it as `Action: [primary] ([link]) + [secondary]`.

## Step 7 of 8: The build

Read `references/build.md` and follow it from start to end. The order:

1. Check the current stable versions and the Node requirement.
2. Create the project (no interactive prompts), install, clean the template, copy the user's files, start Git.
3. Write the components and all the site copy.
4. **Check all the copy against `references/writing-rules.md`.** Apply every rule and the final checklist to every visible text on the site: headings, buttons, cards, FAQ, footer, `<title>` and meta description.
5. Build, then a real preview on mobile (375px) and desktop. Run `scripts/check-mobile.mjs` and fix everything it reports until it passes (see `build.md`, sections 6b and 8). The site must look and work well on a phone.
6. Go through the checklist in `build.md`.

Give the user short progress messages along the way ("Step 7 of 8: the project is set up, now I'm writing the sections."). At the end, show a summary and how to see the site on their computer.

## Step 8 of 8: Publishing

Read `references/publishing.md`. In short:

1. **Before writing the README**, ask: "Do you want me to put the site online now?"
2. If yes: check the GitHub and Vercel connectors, create a **private** GitHub repository named after the project, push the code, import it into Vercel and deploy, then give the user the one manual step (Connect Git Repository on vercel.com) and the two addresses.
3. Write `README.md` for what actually happened: the real addresses if you published, the manual steps if not.
4. Ask about a custom domain (optional, always a manual step, paid by the user).

---

## Final summary (after Step 8, always, also in demo mode)

A short summary: what you built, the folder, the live address (if any), what still needs replacing (if anything), and where the written steps are (README). Tell them they can delete the `temp-safe-to-delete/` folder at any time.

---

## Changes after the build

If the user asks for changes after Step 7 or 8:
- check the request for advanced features (Rule 12);
- make the change, check any new copy against `references/writing-rules.md`, rebuild, and look at the site again (run `check-mobile.mjs` again if the layout changed);
- if the site is already published, publish again the same way (see "Updates" in `publishing.md`).

When the user asks to "run locally", start `npm run dev` in the background and give them the local address.
